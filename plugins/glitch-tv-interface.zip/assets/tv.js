(function(){'use strict';
var C=window.GTV||{},A=C.api,
    V=document.getElementById('view'),
    N=document.getElementById('nav'),
    SD=document.getElementById('side'),
    PL=document.getElementById('pl'),
    VD=document.getElementById('vd'),
    IF=document.getElementById('if'),
    RESUME_PROMPT=document.getElementById('resumePrompt'),
    RESUME_PROMPT_TITLE=document.getElementById('resumePromptTitle'),
    RESUME_PROMPT_TIME=document.getElementById('resumePromptTime'),
    RESUME_PROMPT_CONTINUE=document.getElementById('resumePromptContinue'),
    RESUME_PROMPT_RESTART=document.getElementById('resumePromptRestart'),
    RESUME_PROMPT_CANCEL=document.getElementById('resumePromptCancel'),
    SV_MODAL=document.getElementById('svModal'),
    SV_BG=document.getElementById('svBg'),
    SV=document.getElementById('sv'),
    PB=document.getElementById('pb'),
    SEEK_BADGE=document.getElementById('seekBadge'),
    PB_LANG_BTN=document.getElementById('pbLangBtn'),
    PB_LANG_LABEL=document.getElementById('pbLangLabel'),
    PB_RW_BTN=document.getElementById('pbRwBtn'),
    PB_PLAY_BTN=document.getElementById('pbPlayBtn'),
    PB_PLAY_ICON=document.getElementById('pbPlayIcon'),
    PB_FF_BTN=document.getElementById('pbFfBtn'),
    PB_CLOSE_BTN=document.getElementById('pbCloseBtn'),
    PB_PREV_EP=document.getElementById('pbPrevEpBtn'),
    PB_NEXT_EP=document.getElementById('pbNextEpBtn'),
    PB_EP_SUBTITLE=document.getElementById('pbEpSubtitle'),
    PROGRESS_BAR=document.getElementById('progressBar'),
    BAR_TOOLTIP=document.getElementById('barTooltip'),
    ST=document.getElementById('st'),
    LD=document.getElementById('ld'),
    LD_MODAL=document.getElementById('ldModal'),
    LD_MODAL_SUB=document.getElementById('ldModalSub'),
    TS=document.getElementById('ts'),
    TL=document.getElementById('tl'),
    TP=document.getElementById('tip'),
    HAMB=document.getElementById('hamb'),
    HB_BG=document.getElementById('hambBg'),
    HB_TITLE=document.getElementById('hambTitle'),
    HB_ICON=document.getElementById('hambIcon'),
    HB_BODY=document.getElementById('hambBody'),
    HB_CLOSE=document.getElementById('hambClose');

if(C.accent)document.documentElement.style.setProperty('--a',C.accent);
var themeVars={a:'--a',b:'--b',bg:'--bg',s:'--s',s2:'--s2',t:'--t',m:'--m',bd:'--bd'};
var MAINTENANCE_ICONS={
  tools:'<svg viewBox="0 0 24 24"><path d="M14.7 6.3a5 5 0 0 0-6.4 6.4L3 18l3 3 5.3-5.3a5 5 0 0 0 6.4-6.4l-3 3-3-3 3-3Z"/><path d="m14 4 2-2 6 6-2 2"/></svg>',
  gear:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.7-.7a8 8 0 0 1-1.6.9L16 21h-2.8l-.3-1.8a8 8 0 0 1-1.8 0L10.8 21H8l-.2-2.2a8 8 0 0 1-1.6-.9l-1.7.7-1.4-2.4 1.4-1.1a8 8 0 0 1-.2-1.9l-1.6-.9 1-2.6 1.8.2a8 8 0 0 1 1.2-1.3L6.2 5l2.5-1.3 1.1 1.4a8 8 0 0 1 1.9-.2l.8-1.7 2.7.7-.1 1.9a8 8 0 0 1 1.5 1l1.7-.8 1.6 2.3-1.3 1.3a8 8 0 0 1 .3 1.8l1.7.8-.7 2.7-1.9-.1a8 8 0 0 1-1.1 1.2Z"/></svg>',
  refresh:'<svg viewBox="0 0 24 24"><path d="M20 7v5h-5M4 17v-5h5"/><path d="M6.1 9a7 7 0 0 1 11.6-2L20 12M4 12l2.3 5a7 7 0 0 0 11.6-2"/></svg>',
  shield:'<svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/><path d="m9 12 2 2 4-4"/></svg>',
  sparkles:'<svg viewBox="0 0 24 24"><path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z"/><path d="m19 14 .9 2.1L22 17l-2.1.9L19 20l-.9-2.1L16 17l2.1-.9L19 14ZM5 3l.7 1.7L7.5 5.5l-1.8.7L5 8l-.7-1.8-1.8-.7 1.8-.8L5 3Z"/></svg>',
  clock:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>'
};
Object.keys(themeVars).forEach(function(key){
  var color=C.theme&&C.theme[key];
  if(typeof color==='string'&&/^#[0-9a-f]{6}$/i.test(color))document.documentElement.style.setProperty(themeVars[key],color);
});
var maintenanceColorVars={bg:'--maintenance-bg',text:'--maintenance-text',accent:'--maintenance-accent'};
Object.keys(maintenanceColorVars).forEach(function(key){
  var color=C.maintenance&&C.maintenance[key];
  if(typeof color==='string'&&/^#[0-9a-f]{6}$/i.test(color))document.documentElement.style.setProperty(maintenanceColorVars[key],color);
});
document.title=C.name||document.title;

var stack=[],cur=null,heroT,P={on:false,list:[],i:0,serieContext:null,watchItem:null,resumeAt:0,resumeChoice:null,lastWatchSave:0,watchCompleted:false},pbT,viewSeq=0,
    hambOpener=null,svModalOpener=null,serverTimeoutTimer=null,
  svScrollLock=null,
    SV_DATA={title:'',langs:{},langKeys:[],selectedLang:null},
    KEYS={37:'l',38:'u',39:'r',40:'d'};

function showLoading(msg){
  if(LD_MODAL){
    if(LD_MODAL_SUB)LD_MODAL_SUB.textContent=msg||'Buscando los mejores servidores disponibles…';
    LD_MODAL.hidden=false;
    document.body.style.overflow='hidden';
  }else if(LD){
    LD.hidden=false;
  }
}

function hideLoading(){
  if(LD_MODAL)LD_MODAL.hidden=true;
  if(LD)LD.hidden=true;
  document.body.style.overflow='';
}

/* ── Sistema de Favoritos / Mi Lista en LocalStorage ── */
var FAV_KEY='gtv_favorites';
var CONTINUE_KEY='gtv_continue_watching';
var favRemoveModal=null,favRemoveTitle=null,favRemoveMessage=null,
    favRemoveCancel=null,favRemoveConfirm=null,favRemoval=null,favScrollLock=null;

function getFavs(){
  try{return JSON.parse(localStorage.getItem(FAV_KEY)||'[]')}catch(e){return[]}
}
function saveFavs(list){
  try{localStorage.setItem(FAV_KEY,JSON.stringify(list))}catch(e){}
}
function sameFavorite(a,b){
  if(!a||!b)return false;
  if(a.id&&b.id&&String(a.id)===String(b.id))return true;
  if(a.url&&b.url&&a.url===b.url)return true;
  return !!(a.title&&b.title&&nrm(a.title)===nrm(b.title)&&(!a.type||!b.type||a.type===b.type));
}
function isFav(it){
  return getFavs().some(function(saved){return sameFavorite(saved,it)});
}
function removeFavorite(it){
  var list=getFavs(),next=list.filter(function(saved){return !sameFavorite(saved,it)});
  if(next.length===list.length)return false;
  saveFavs(next);
  return true;
}
function lockFavoriteScroll(){
  if(favScrollLock)return;
  var scrollbarWidth=Math.max(0,window.innerWidth-document.documentElement.clientWidth),
      bodyPadding=parseFloat(window.getComputedStyle(document.body).paddingRight)||0;
  favScrollLock={
    body:document.body.style.overflow,
    html:document.documentElement.style.overflow,
    padding:document.body.style.paddingRight,
    scrollY:window.scrollY
  };
  if(scrollbarWidth)document.body.style.paddingRight=(bodyPadding+scrollbarWidth)+'px';
  document.body.style.overflow='hidden';
  document.documentElement.style.overflow='hidden';
}
function unlockFavoriteScroll(){
  if(!favScrollLock)return;
  var scrollY=favScrollLock.scrollY;
  document.body.style.overflow=favScrollLock.body;
  document.documentElement.style.overflow=favScrollLock.html;
  document.body.style.paddingRight=favScrollLock.padding;
  favScrollLock=null;
  if(window.scrollY!==scrollY)window.scrollTo(window.scrollX,scrollY);
}
function ensureFavoriteRemoveModal(){
  if(favRemoveModal)return;
  favRemoveModal=E('div','fav-remove-overlay');
  favRemoveModal.hidden=true;
  var dialog=E('div','fav-remove-dialog');
  dialog.setAttribute('role','dialog');
  dialog.setAttribute('aria-modal','true');
  dialog.setAttribute('aria-labelledby','favRemoveTitle');
  dialog.setAttribute('aria-describedby','favRemoveMessage');
  favRemoveTitle=E('h2',null,'Quitar de Mi Lista');
  favRemoveTitle.id='favRemoveTitle';
  favRemoveMessage=E('p');
  favRemoveMessage.id='favRemoveMessage';
  var actions=E('div','fav-remove-actions');
  favRemoveCancel=E('button','f fav-cancel-btn','Conservar');
  favRemoveCancel.type='button';
  favRemoveConfirm=E('button','f fav-confirm-btn','Eliminar');
  favRemoveConfirm.type='button';
  actions.appendChild(favRemoveCancel);
  actions.appendChild(favRemoveConfirm);
  dialog.appendChild(E('span','fav-remove-icon','!'));
  dialog.appendChild(favRemoveTitle);
  dialog.appendChild(favRemoveMessage);
  dialog.appendChild(actions);
  favRemoveModal.appendChild(dialog);
  favRemoveModal.addEventListener('click',function(e){
    if(e.target===favRemoveModal)closeFavoriteRemoveModal();
  });
  favRemoveModal.addEventListener('keydown',function(e){
    if(e.key!=='Tab')return;
    var buttons=[].slice.call(favRemoveModal.querySelectorAll('button:not(:disabled)'));
    if(!buttons.length)return;
    var first=buttons[0],last=buttons[buttons.length-1];
    if(e.shiftKey&&document.activeElement===first){
      last.focus();
      e.preventDefault();
    }else if(!e.shiftKey&&document.activeElement===last){
      first.focus();
      e.preventDefault();
    }
  });
  favRemoveCancel.onclick=closeFavoriteRemoveModal;
  favRemoveConfirm.onclick=confirmFavoriteRemoval;
  document.body.appendChild(favRemoveModal);
}
function requestFavoriteRemoval(it,onRemove,trigger){
  ensureFavoriteRemoveModal();
  favRemoval={kind:'favorite',item:it,onRemove:onRemove,trigger:trigger||document.activeElement};
  favRemoveTitle.textContent='Quitar de Mi Lista';
  favRemoveMessage.textContent='¿Quieres quitar «'+(it.title||'este título')+'» de tu lista?';
  favRemoveModal.hidden=false;
  lockFavoriteScroll();
  focusQuiet(favRemoveCancel);
}
function requestContinueRemoval(entry,trigger){
  ensureFavoriteRemoveModal();
  favRemoval={kind:'continue',entry:entry,trigger:trigger||document.activeElement};
  favRemoveTitle.textContent='Quitar de Continuar viendo';
  favRemoveMessage.textContent='Se eliminará la tarjeta y el progreso guardado de «'+((entry.item&&entry.item.title)||'este título')+'». ¿Quieres continuar?';
  favRemoveCancel.textContent='Conservar';
  favRemoveModal.hidden=false;
  lockFavoriteScroll();
  focusQuiet(favRemoveCancel);
}
function closeFavoriteRemoveModal(){
  if(!favRemoveModal||favRemoveModal.hidden)return;
  favRemoveModal.hidden=true;
  unlockFavoriteScroll();
  var trigger=favRemoval&&favRemoval.trigger;
  favRemoval=null;
  if(trigger&&trigger.isConnected)focusQuiet(trigger);
}
function confirmFavoriteRemoval(){
  if(!favRemoval)return;
  var pending=favRemoval,removed=pending.kind==='continue'
    ? removeContinueEntry(pending.entry)
    : removeFavorite(pending.item);
  favRemoveModal.hidden=true;
  unlockFavoriteScroll();
  favRemoval=null;
  if(removed){
    if(pending.onRemove)pending.onRemove();
    toast(pending.kind==='continue'?'Eliminado de Continuar viendo':'Eliminado de Mi Lista');
  }
  if(pending.trigger&&pending.trigger.isConnected){
    focusQuiet(pending.trigger);
  }else if(V){
    focusQuiet(V.querySelector('.continue-row .continue-remove-btn, .fav-remove-btn, .fav-card .po, .fav-empty-prompt .f'));
  }
}
function toggleFav(it){
  if(!it)return false;
  var list=getFavs();
  var idx=list.findIndex(function(saved){return sameFavorite(saved,it)});
  var added=false;
  if(idx>-1){
    list.splice(idx,1);
    toast('Eliminado de Mi Lista');
  }else{
    list.unshift({
      id:it.id,
      url:it.url,
      title:it.title,
      type:it.type,
      poster:it.poster||it.backdrop,
      backdrop:it.backdrop||it.poster,
      year:it.year,
      rating:it.rating,
      genres:it.genres||[],
      overview:it.overview||''
    });
    toast('Añadido a Mi Lista');
    added=true;
  }
  saveFavs(list);
  return added;
}

function watchKey(it){
  if(!it)return'';
  var type=it.type||'video';
  if(it.id)return type+':id:'+String(it.id);
  if(it.url)return type+':url:'+String(it.url);
  return type+':title:'+nrm(it.title||'');
}
function getContinueItems(){
  try{
    var items=JSON.parse(localStorage.getItem(CONTINUE_KEY)||'[]');
    return Array.isArray(items)?items.filter(function(entry){
      return entry&&entry.item&&entry.currentTime>0&&entry.duration>0;
    }):[];
  }catch(e){return[]}
}
function removeContinueProgress(it){
  var key=watchKey(it);
  if(!key)return;
  try{
    localStorage.setItem(CONTINUE_KEY,JSON.stringify(getContinueItems().filter(function(entry){return entry.key!==key})));
  }catch(e){}
}
function removeContinueEntry(entry){
  if(!entry||!entry.key)return false;
  try{
    var items=getContinueItems().filter(function(saved){return saved.key!==entry.key});
    localStorage.setItem(CONTINUE_KEY,JSON.stringify(items));
    updateContinueSection();
    return true;
  }catch(e){
    toast('No se pudo eliminar el progreso guardado');
    return false;
  }
}
function hideResumePrompt(){
  if(RESUME_PROMPT)RESUME_PROMPT.hidden=true;
  PL.classList.remove('is-resume-prompt');
}
function resumeVideoAt(seconds){
  var target=Math.max(0,Number(seconds)||0),attempts=0,timer=null,finished=false;
  if(isFinite(VD.duration)&&VD.duration>0)target=Math.min(target,Math.max(0,VD.duration-2));
  P.resumeAt=0;
  function cleanup(){
    clearTimeout(timer);
    VD.removeEventListener('seeked',onSeeked);
  }
  function play(){
    if(finished)return;
    finished=true;
    cleanup();
    VD.play().catch(function(){toast('No se pudo reanudar el video. Pulsa reproducir para intentarlo de nuevo.')});
  }
  function onSeeked(){
    if(Math.abs((VD.currentTime||0)-target)<=3){play();return}
    if(attempts<4)timer=setTimeout(seek,500);
    else{cleanup();toast('No se pudo ubicar el minuto guardado en este servidor.');play()}
  }
  function seek(){
    attempts++;
    try{
      VD.currentTime=target;
      if(!VD.seeking&&Math.abs((VD.currentTime||0)-target)<=3){play();return}
    }catch(error){
      if(attempts>=4){cleanup();toast('El servidor no permite reanudar desde el minuto guardado.');play();return}
    }
    if(attempts>=4)timer=setTimeout(function(){
      if(Math.abs((VD.currentTime||0)-target)<=3)play();
      else{cleanup();toast('No se pudo ubicar el minuto guardado en este servidor.');play()}
    },1500);
    else timer=setTimeout(seek,1500);
  }
  VD.addEventListener('seeked',onSeeked);
  seek();
}
function showResumePrompt(){
  var choice=P.resumeChoice;
  if(!choice||choice.shown||!RESUME_PROMPT)return;
  choice.shown=true;
  clearTimeout(serverTimeoutTimer);
  status('');
  PL.classList.add('is-resume-prompt');
  RESUME_PROMPT.hidden=false;
  if(RESUME_PROMPT_TITLE)RESUME_PROMPT_TITLE.textContent='¿Cómo quieres reproducir '+(choice.item.title||'este contenido')+'?';
  if(RESUME_PROMPT_TIME){
    var episodeLabel=choice.episode?'T'+choice.episode.season+' E'+choice.episode.number+' · ':'';
    RESUME_PROMPT_TIME.textContent=episodeLabel+'Guardado en '+fmtTime(choice.time)+(choice.duration>0?' de '+fmtTime(choice.duration):'');
  }
  RESUME_PROMPT_CONTINUE.onclick=function(){
    hideResumePrompt();
    P.resumeChoice=null;
    resumeVideoAt(choice.time);
  };
  RESUME_PROMPT_RESTART.onclick=function(){
    hideResumePrompt();
    P.resumeChoice=null;
    P.resumeAt=0;
    removeContinueProgress(choice.item);
    delete choice.item.continueAt;
    delete choice.item.continueDuration;
    delete choice.item.continueEpisode;
    if(cur&&cur.v==='detail'&&cur.a&&sameFavorite(cur.a,choice.item)){
      delete cur.a.continueAt;
      delete cur.a.continueDuration;
      delete cur.a.continueEpisode;
      pushURL('detail',cur.a,true);
    }
    try{VD.currentTime=0}catch(e){}
    VD.play().catch(function(){});
  };
  if(RESUME_PROMPT_CANCEL)RESUME_PROMPT_CANCEL.onclick=closeP;
  focus(RESUME_PROMPT_CONTINUE);
}
function requestVideoPlayback(){
  if(!P.on||PL.hidden)return;
  if(P.resumeChoice){
    if(VD.readyState>=1)showResumePrompt();
    return;
  }
  VD.play().catch(function(){});
}
function saveContinueProgress(force){
  if(!P.on||!P.watchItem||!VD||VD.hidden||P.watchCompleted)return;
  var now=Date.now(),current=VD.currentTime||0,duration=VD.duration||0;
  if(!isFinite(current)||!isFinite(duration)||duration<30)return;
  if(current>=duration-8){removeContinueProgress(P.watchItem);return}
  if(current<5||(!force&&now-(P.lastWatchSave||0)<5000))return;

  var item=P.watchItem,episode=null,ctx=P.serieContext;
  if(ctx&&ctx.allEpisodes&&ctx.allEpisodes[ctx.epIndex]){
    var ep=ctx.allEpisodes[ctx.epIndex];
    episode={season:ep.season||1,number:ep.number||1,title:ep.title||''};
  }
  var entry={
    key:watchKey(item),
    item:{id:item.id,url:item.url,title:item.title,type:item.type,poster:item.poster||item.backdrop,backdrop:item.backdrop||item.poster,year:item.year,rating:item.rating,genres:item.genres||[],overview:item.overview||''},
    currentTime:current,
    duration:duration,
    updated:now,
    episode:episode
  };
  var items=getContinueItems().filter(function(saved){return saved.key!==entry.key});
  items.unshift(entry);
  try{localStorage.setItem(CONTINUE_KEY,JSON.stringify(items.slice(0,12)))}catch(e){}
  P.lastWatchSave=now;
  if(cur&&cur.v==='detail'&&cur.a&&sameFavorite(cur.a,item)){
    cur.a.continueAt=current;
    cur.a.continueDuration=duration;
    cur.a.continueEpisode=episode;
    pushURL('detail',cur.a,true);
  }
}
function resumeContinueItem(entry){
  var item=entry&&entry.item;
  if(!item)return;
  var detailItem={};
  Object.keys(item).forEach(function(key){detailItem[key]=item[key]});
  detailItem.continueAt=Math.max(0,Number(entry.currentTime)||0);
  detailItem.continueDuration=Math.max(0,Number(entry.duration)||0);
  detailItem.continueEpisode=entry.episode||null;
  go('detail',detailItem);
}
function continueCard(entry){
  var item=entry.item,b=E('div','card continue-card'),poster=E('div','f po continue-poster');
  poster.setAttribute('role','button');
  poster.setAttribute('aria-label','Continuar viendo '+(item.title||'este contenido'));
  poster.tabIndex=0;
  poster.onclick=function(){resumeContinueItem(entry)};
  poster.onkeydown=function(event){
    if(event.key==='Enter'||event.key===' '){event.preventDefault();resumeContinueItem(entry)}
  };
  if(item.poster){
    var img=new Image();
    img.alt='';
    attachLazyImage(poster,img,item.poster);
  }else poster.textContent=item.title||'Continuar viendo';
  var track=E('span','continue-progress-track'),fill=E('i','continue-progress-fill');
  fill.style.width=Math.max(2,Math.min(100,(entry.currentTime/entry.duration)*100))+'%';
  track.appendChild(fill);
  poster.appendChild(track);
  var play=E('span','continue-play');
  play.appendChild(ic('play'));
  poster.appendChild(play);
  var remove=E('button','f fav-remove-btn continue-remove-btn');
  remove.type='button';
  remove.title='Quitar de Continuar viendo';
  remove.setAttribute('aria-label','Quitar '+(item.title||'este contenido')+' de Continuar viendo');
  remove.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>';
  remove.onclick=function(event){
    event.preventDefault();
    event.stopPropagation();
    requestContinueRemoval(entry,remove);
  };
  b.appendChild(poster);
  b.appendChild(remove);
  b.appendChild(E('span','ct',item.title||'Sin título'));
  var sub=entry.episode?'T'+entry.episode.season+' E'+entry.episode.number+' · ':'Reanudar · ';
  sub+='Quedan '+fmtTime(Math.max(0,entry.duration-entry.currentTime));
  b.appendChild(E('span','cs continue-sub',sub));
  return b;
}

/* ── Modal Selector de Idiomas y Servidores ── */
function lockSvScroll(){
  if(svScrollLock)return;
  svScrollLock={
    body:document.body.style.overflow,
    html:document.documentElement.style.overflow
  };
  document.body.style.overflow='hidden';
  document.documentElement.style.overflow='hidden';
}

function unlockSvScroll(){
  if(!svScrollLock)return;
  document.body.style.overflow=svScrollLock.body;
  document.documentElement.style.overflow=svScrollLock.html;
  svScrollLock=null;
}

function closeSvModal(){
  if(SV_MODAL)SV_MODAL.hidden=true;
  unlockSvScroll();
  if(!P.on){
    if(svModalOpener&&svModalOpener.focus){
      try{svModalOpener.focus({preventScroll:true})}catch(e){svModalOpener.focus()}
    }
  }
}
if(SV_BG)SV_BG.onclick=closeSvModal;

function E(t,c,x){
  var e=document.createElement(t);
  if(c)e.className=c;
  if(x!=null)e.textContent=x;
  return e;
}
function enc(s){return encodeURIComponent(s||'')}

/* ── Indicador de carga superior ── */
var busy=0;
function tl(d){busy=Math.max(0,busy+d);if(TL)TL.classList.toggle('on',busy>0)}

/* ── Caché y deduplicación de peticiones API en memoria ── */
var CACHE=Object.create(null),IN_FLIGHT=Object.create(null),CACHE_LIMIT=48,CACHE_CLOCK=0;

function pruneApiCache(now){
  Object.keys(CACHE).forEach(function(key){
    var entry=CACHE[key];
    if(now-entry.ts>=entry.ttl)delete CACHE[key];
  });
}

function storeApiCache(key,data,ttl,now){
  pruneApiCache(now);
  var keys=Object.keys(CACHE);
  if(keys.length>=CACHE_LIMIT){
    var oldest=keys[0];
    keys.forEach(function(cacheKey){
      if(CACHE[cacheKey].used<CACHE[oldest].used)oldest=cacheKey;
    });
    delete CACHE[oldest];
  }
  CACHE[key]={ts:now,ttl:ttl,used:++CACHE_CLOCK,data:data};
}

function apiFetch(path,ttlMs,timeoutMs){
  var key=path,now=Date.now(),cached=CACHE[key];
  if(cached&&now-cached.ts<cached.ttl){
    cached.used=++CACHE_CLOCK;
    return Promise.resolve(cached.data);
  }
  if(cached)delete CACHE[key];
  if(IN_FLIGHT[key])return IN_FLIGHT[key];
  tl(1);
  var cacheTtl=ttlMs||180000,
      controller=typeof AbortController==='function'?new AbortController():null,
      timedOut=false,
      timeoutId,
      request=fetch(A+'/'+path,controller?{signal:controller.signal}:undefined)
    .then(function(r){
      if(!r.ok)throw new Error('HTTP '+r.status);
      return r.json();
    })
    .then(function(j){
      if(timedOut)throw new Error('La solicitud tardó demasiado');
      if(!j.success)throw new Error(j.error&&j.error.message||'Error');
      storeApiCache(key,j,cacheTtl,Date.now());
      return j;
    }),
      timeout=new Promise(function(resolve,reject){
        timeoutId=setTimeout(function(){
          timedOut=true;
          if(controller)controller.abort();
          reject(new Error('La solicitud tardó demasiado. Inténtalo de nuevo.'));
        },timeoutMs||45000);
      }),
      p=Promise.race([request,timeout]).then(function(j){
        clearTimeout(timeoutId);
        tl(-1);
        delete IN_FLIGHT[key];
        return j;
      },function(e){
        clearTimeout(timeoutId);
        if(controller&&!timedOut)controller.abort();
      tl(-1);
      delete IN_FLIGHT[key];
        throw e;
      });
  IN_FLIGHT[key]=p;
  return p;
}

function G(p,ttl,timeoutMs){return apiFetch(p,ttl,timeoutMs)}

var TZ='';
try{TZ=Intl.DateTimeFormat().resolvedOptions().timeZone||''}catch(e){}

function S(q,ttl){
  return apiFetch('ext.php?plugin=glitch-tv-interface&r=sports'+(TZ?'&zona='+enc(TZ):'')+(q||''),ttl!=null?ttl:30000)
    .then(function(j){return j.data});
}

function ymd(d){
  return d.getFullYear()+'-'+('0'+(d.getMonth()+1)).slice(-2)+'-'+('0'+d.getDate()).slice(-2);
}

function when(it){
  if(it.live)return'EN VIVO';
  if(it.status==='finalizado')return'Finalizado';
  var n=new Date(),d=it.date,
      l=d===ymd(n)?'Hoy':d===ymd(new Date(n.getTime()+864e5))?'Mañana':(d?d.slice(8,10)+'/'+d.slice(5,7):'');
  return[l,it.time].filter(Boolean).join(' · ');
}

function attachLazyImage(container,image,src,onError){
  image.loading='lazy';
  image.decoding='async';
  container.classList.add('image-loading');
  container.setAttribute('aria-busy','true');
  var settled=false;

  function finish(){
    if(settled)return;
    settled=true;
    container.classList.remove('image-loading');
    container.removeAttribute('aria-busy');
  }

  function loaded(){
    finish();
  }

  image.onload=loaded;
  image.onerror=function(){
    finish();
    image.remove();
    if(onError)onError();
  };
  container.appendChild(image);
  image.src=src;
  if(image.complete){
    if(image.naturalWidth)loaded();
    else image.onerror();
  }
}

function lgo(u,n,c){
  var w=E('span',c||'lgo'),t=(n||'?').slice(0,3).toUpperCase();
  if(u){
    var m=new Image();
    m.alt=n||'';
    attachLazyImage(w,m,u,function(){w.classList.add('tx');w.textContent=t});
  }else{
    w.classList.add('tx');
    w.textContent=t;
  }
  return w;
}

function teams(it,k){
  var w=E('div',k);
  if(it.home||it.away){
    w.appendChild(lgo(it.home_logo,it.home));
    w.appendChild(E('b',null,'vs'));
    w.appendChild(lgo(it.away_logo,it.away));
  }else{
    var sp=E('span','big');
    sp.appendChild(ic(it.sport_id?getSportIcon(it.sport_id):'sports'));
    w.appendChild(sp);
  }
  return w;
}

function evCard(it){
  var b=E('button','f ecard');
  b.onclick=function(){
    // Cargar opciones de reproducción directamente, sin pantalla de detalles
    if(it.servers&&it.servers.length){
      playEv(it);
    }else{
      toast('Este evento aún no tiene servidores disponibles');
    }
  };
  b.appendChild(E('em','eb'+(it.live?' live':it.status==='finalizado'?' end':''),it.live?'EN VIVO':it.status==='finalizado'?'FIN':(it.time||when(it))));
  b.appendChild(teams(it,'et'));
  b.appendChild(E('span','ect',it.title));
  b.appendChild(E('span','esub',[it.sport,it.league,it.live||!it.time?'':it.time].filter(Boolean).join(' · ')));
  return b;
}

function ref(it){return it.id?'id='+enc(it.id):'url='+enc(it.url)}
function ref(it){return it.id?'id='+enc(it.id):'url='+enc(it.url)}
function serverEmbedParam(){return'&embeds='+(C.includeEmbeds?'1':'0')}

function focus(el){
  if(!el)return;
  try{el.focus({preventScroll:true})}catch(e){el.focus()}
  el.scrollIntoView({block:'nearest',inline:'nearest',behavior:'auto'});
}

function focusQuiet(el){
  if(!el)return;
  try{el.focus({preventScroll:true})}catch(e){el.focus()}
}

function toast(m){
  if(!TS)return;
  TS.innerHTML='<span class="ic"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg></span><span>'+m+'</span>';
  TS.hidden=false;
  clearTimeout(toast.t);
  toast.t=setTimeout(function(){TS.hidden=true},3500);
}

/* ── Tarjeta de Película/Serie con Lazy Loading ligero ── */
function card(it){
  var b=E('button','f card'),p=E('div','po');
  b.onclick=function(){go('detail',it)};
  if(it.poster){
    var m=new Image();
    m.alt='';
    attachLazyImage(p,m,it.poster);
  }else{
    p.textContent=it.title;
  }
  if(it.rating)p.appendChild(E('em','rt','★ '+Number(it.rating).toFixed(1)));
  b.appendChild(p);
  b.appendChild(E('span','ct',it.title));
  b.appendChild(E('span','cs',[it.year,it.type==='serie'?'Serie':'Película'].filter(Boolean).join(' · ')));
  return b;
}

/* ── Tarjeta para «Mi Lista» (Grid Cuadrícula con Botón Discreto para Eliminar) ── */
function favCard(it,onRemove,confirmRemove){
  var b=E('div','fav-card');
  var po=E('div','f po');
  po.setAttribute('role','button');
  po.tabIndex=0;

  function openDetail(ev){
    if(ev && ev.target && ev.target.closest && ev.target.closest('.fav-remove-btn'))return;
    go('detail',it);
  }

  po.onclick=function(ev){openDetail(ev)};
  po.onkeydown=function(ev){
    if(ev.key==='Enter'||ev.key===' '){
      ev.preventDefault();
      openDetail(ev);
    }
  };

  if(it.poster){
    var m=new Image();
    m.alt='';
    attachLazyImage(po,m,it.poster);
  }else{
    po.textContent=it.title;
  }
  if(it.rating)po.appendChild(E('em','rt','★ '+Number(it.rating).toFixed(1)));
  b.appendChild(po);

  var rmBtn=E('button','f fav-remove-btn');
  rmBtn.type='button';
  rmBtn.title='Quitar de Mi Lista';
  rmBtn.setAttribute('aria-label','Quitar de Mi Lista');
  rmBtn.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>';
  rmBtn.onclick=function(e){
    e.preventDefault();
    e.stopPropagation();
    function finishRemove(){if(onRemove)onRemove(b)}
    if(confirmRemove){
      requestFavoriteRemoval(it,finishRemove,rmBtn);
    }else if(removeFavorite(it)){
      toast('Eliminado de Mi Lista');
      finishRemove();
    }
  };
  po.appendChild(rmBtn);

  b.appendChild(E('span','ct',it.title));
  b.appendChild(E('span','cs',[it.year,it.type==='serie'?'Serie':'Película'].filter(Boolean).join(' · ')));
  return b;
}

function skC(k,n){
  var f=document.createDocumentFragment();
  for(var i=0;i<n;i++){
    var c=E('div','skc');
    c.appendChild(E('div','sk skp'));
    c.appendChild(E('div','sk skl'));
    c.appendChild(E('div','sk skl s'));
    f.appendChild(c);
  }
  k.appendChild(f);
}
function skE(k,n){
  var f=document.createDocumentFragment();
  for(var i=0;i<n;i++)f.appendChild(E('div','sk ske'));
  k.appendChild(f);
}
function skQ(k,n){
  var f=document.createDocumentFragment();
  for(var i=0;i<n;i++)f.appendChild(E('div','sk skq'));
  k.appendChild(f);
}

function row(t){
  var s=E('section','row'),k=E('div','tr');
  s.appendChild(E('h2',null,t));
  s.appendChild(k);
  skC(k,6);
  return{s:s,k:k};
}

/* ── Relleno optimizado de filas por lotes ── */
function fill(r,a){
  if(!a||!a.length){
    if(r.s&&r.s.parentNode)r.s.remove();
    return;
  }
  r.k.innerHTML='';
  var frag=document.createDocumentFragment();
  var limit=Math.min(a.length,20);
  for(var i=0;i<limit;i++){
    frag.appendChild(card(a[i]));
  }
  r.k.appendChild(frag);
}

function genres(){
  return G('genres.php',300000).then(function(j){
    var d=j.data,o=[];
    if(Array.isArray(d)){
      d.forEach(function(g){
        o.push(typeof g==='string'?[g,g]:[g.slug||g.id||g.name,g.name||g.label||g.slug]);
      });
    }else if(d&&typeof d==='object'){
      Object.keys(d).forEach(function(k){
        o.push([k,typeof d[k]==='string'?d[k]:(d[k].name||k)]);
      });
    }
    return o;
  }).catch(function(){return[]});
}

function pushURL(v,a,replace){
  var hash='home';
  if(v==='favorites')hash='favorites';
  else if(v==='sports')hash='sports';
  else if(v==='search')hash='search:'+(a&&a.q?encodeURIComponent(a.q):'');
  else if(v==='browse'){
    var bg=a&&(typeof a==='object'?a.g:a)||'';
    hash='browse:'+encodeURIComponent(bg);
  }
  else if(v==='detail'&&a&&a.id){
    try{sessionStorage.setItem('gtv_det_'+String(a.id),JSON.stringify(a))}catch(x){}
    var resumeParams='';
    if(Number(a.continueAt)>0){
      if(a.continueEpisode){
        resumeParams='?media=episode&season='+encodeURIComponent(a.continueEpisode.season||1)+'&episode='+encodeURIComponent(a.continueEpisode.number||1)+'&time='+encodeURIComponent(Math.floor(a.continueAt));
      }else{
        resumeParams='?media=movie&time='+encodeURIComponent(Math.floor(a.continueAt));
      }
    }
    hash='detail:'+(a.type||'pelicula')+':'+encodeURIComponent(String(a.id))+resumeParams;
  }
  if(window.history&&window.history.pushState){
    try{
      if(replace)window.history.replaceState({v:v},'','#'+hash);
      else window.history.pushState({v:v},'','#'+hash);
    }catch(x){}
  }
}

function parseInitURL(){
  var hash=(location.hash||'').replace(/^#/,'');
  if(!hash||hash==='home')return{v:'home',a:null};
  if(hash==='favorites')return{v:'favorites',a:null};
  if(hash==='sports')return{v:'sports',a:null};
  var m;
  if((m=hash.match(/^search:(.*)$/)))return{v:'search',a:{q:decodeURIComponent(m[1]||'')}};
  if((m=hash.match(/^browse:(.*)$/)))return{v:'browse',a:{g:decodeURIComponent(m[1]||'')}};
  if((m=hash.match(/^detail:([^:]+):([^?]+)(?:\?(.*))?$/))){
    var stored=null;
    try{stored=JSON.parse(sessionStorage.getItem('gtv_det_'+decodeURIComponent(m[2]))||'null');}catch(x){}
    if(stored){
      var params=new URLSearchParams(m[3]||''),media=params.get('media'),time=Number(params.get('time'))||0;
      if(time>0){
        stored.continueAt=time;
        stored.continueEpisode=media==='episode'?{season:Number(params.get('season'))||1,number:Number(params.get('episode'))||1}:null;
      }
      return{v:'detail',a:stored};
    }
  }
  return{v:'home',a:null};
}

function go(v,a){
  if(cur)stack.push(cur);
  cur={v:v,a:a};
  pushURL(v,a,false);
  render();
}

function exitDetail(){
  while(stack.length&&stack[stack.length-1].v==='detail'){
    stack.pop();
  }
  performBack();
}
var requestExitDetail=exitDetail;

function performBack(){
  var s=stack.pop();
  if(s){cur=s;pushURL(s.v,s.a,false);render();}
  else if(cur&&cur.v!=='home'){cur={v:'home'};pushURL('home',null,false);render();}
}

function back(){
  if(SV_MODAL&&!SV_MODAL.hidden){closeSvModal();return}
  if(HAMB&&!HAMB.hidden){closeHamb();return}
  if(P.on){closeP();return}
  if(cur&&cur.v==='detail'){exitDetail();return}
  performBack();
}

window.addEventListener('popstate',function(){
  if(SV_MODAL&&!SV_MODAL.hidden){closeSvModal();return}
  if(HAMB&&!HAMB.hidden){closeHamb();return}
  if(P.on){closeP();return}
  if(cur&&cur.v==='detail'){exitDetail();return}
  performBack();
});

function ckey(){
  var v=cur&&cur.v,a=cur&&cur.a;
  if(v==='home')return'home';
  if(v==='browse')return a&&typeof a==='object'?'g:'+a.g:'browse:'+a;
  if(v==='favorites')return'favorites';
  if(v==='sports')return'sports:'+(a||'');
  if(v==='event')return'sports:';
  return v==='search'?'search':'';
}

function hl(){
  var k=ckey();
  [SD,N].forEach(function(c){
    if(!c)return;
    [].forEach.call(c.querySelectorAll('.f'),function(b){
      var d=b.dataset;
      b.classList.toggle('on',!!d.k&&(d.k===k||(!!d.p&&k.indexOf(d.p)===0)));
    });
  });
}

function render(){
  clearInterval(heroT);
  var token=++viewSeq;
  V.innerHTML='';
  window.scrollTo(0,0);
  
  // Vista independiente: oculta completamente el menú lateral y navbar en detalles y buscador
  document.body.classList.toggle('is-detail',!!(cur&&cur.v==='detail'));
  document.body.classList.toggle('is-search',!!(cur&&cur.v==='search'));

  if(C.maintenanceMode){
    document.body.classList.add('is-maintenance');
    var maintenanceConfig=C.maintenance||{};
    var maintenance=E('section','maintenance-view'),card=E('div','maintenance-card');
    var maintenanceIcon=maintenanceConfig.icon||'tools',mark=E('span','maintenance-mark');
    function showMaintenanceIcon(){
      if(MAINTENANCE_ICONS[maintenanceIcon])mark.innerHTML=MAINTENANCE_ICONS[maintenanceIcon];
      else mark.textContent=maintenanceIcon||'!';
    }
    showMaintenanceIcon();
    if(typeof maintenanceConfig.image==='string'&&/^https?:\/\//i.test(maintenanceConfig.image)){
      var maintenanceImage=new Image();
      maintenanceImage.className='maintenance-custom-image';
      maintenanceImage.alt='';
      maintenanceImage.onerror=function(){maintenanceImage.remove();showMaintenanceIcon()};
      maintenanceImage.src=maintenanceConfig.image;
      mark.textContent='';
      mark.appendChild(maintenanceImage);
    }
    card.appendChild(mark);
    card.appendChild(E('p','maintenance-eyebrow',C.name||'GlitchTV'));
    card.appendChild(E('h1',null,maintenanceConfig.title||'Modo mantenimiento'));
    card.appendChild(E('p','maintenance-copy',maintenanceConfig.message||'Estamos realizando tareas de mantenimiento. Vuelve pronto.'));
    maintenance.appendChild(card);
    V.appendChild(maintenance);
    return;
  }
  document.body.classList.remove('is-maintenance');
  
  hl();
  var fn={home:home,browse:browse,search:search,detail:detail,sports:sportsV,event:eventV,favorites:favoritesV}[cur.v];
  if(fn)fn(cur.a,token);
  setTimeout(function(){focusQuiet(V.querySelector('.f'))},80);
}

/* ── Vista Mi Lista / Favoritos (Presentación en Cuadrícula Grid sin Slider) ── */
function favoritesV(a,token){
  var list=getFavs();
  var tt=E('div','tt','Mi Lista');
  var grid=E('div','fav-grid');
  V.appendChild(tt);
  V.appendChild(grid);

  function renderEmpty(){
    grid.innerHTML='';
    var empty=E('div','fav-empty-prompt');
    empty.appendChild(ic('heart'));
    empty.appendChild(E('h3',null,'Tu lista está vacía'));
    empty.appendChild(E('p',null,'Añade películas y series a tu lista desde la pantalla de detalles usando el botón «Añadir a Mi Lista».'));
    var goHome=E('button','f pri','Explorar catálogo');
    goHome.onclick=function(){navTo('home')};
    empty.appendChild(goHome);
    grid.appendChild(empty);
    setTimeout(function(){focusQuiet(goHome)},80);
  }

  if(!list.length){
    renderEmpty();
    return;
  }

  var frag=document.createDocumentFragment();
  list.forEach(function(it){
    frag.appendChild(favCard(it,function(cardNode){
      cardNode.remove();
      if(!getFavs().length){
        renderEmpty();
      }
    },true));
  });
  grid.appendChild(frag);
  setTimeout(function(){focusQuiet(grid.querySelector('.po'))},80);
}

function buildContinueSection(){
  var items=getContinueItems();
  if(!items.length)return null;
  var section=E('section','row continue-row'),rail=E('div','tr');
  section.appendChild(E('h2',null,'Continuar viendo'));
  section.appendChild(rail);
  items.slice(0,12).forEach(function(entry){rail.appendChild(continueCard(entry))});
  return section;
}

function updateContinueSection(){
  if(!V||!cur||cur.v!=='home')return;
  var current=V.querySelector('.continue-row'),next=buildContinueSection();
  if(current&&next){
    current.replaceWith(next);
  }else if(current){
    current.remove();
  }else if(next){
    var before=V.querySelector('.ssec, .row');
    if(before)V.insertBefore(next,before);
    else V.appendChild(next);
  }
}

/* ── Vista Inicio (Carga escalonada ligera) ── */
function home(arg,token){
  var hero=E('div','hero sk'),
      defs=[
        ['Películas recientes','latest.php?type=pelicula&per_page=20'],
        ['Series recientes','latest.php?type=serie&per_page=20']
      ],
      R=defs.map(function(d){return row(d[0])});

  V.appendChild(hero);
  G('all.php?type=all&sort=rating&per_page=150',120000,12000).then(function(j){
    if(token!==viewSeq)return;
    var popular=(j.data||[]).filter(function(item){return item&&item.title});
    heroInit(hero,popular.slice(0,10));
  }).catch(function(){
    if(token===viewSeq&&hero.parentNode)hero.remove();
  });

  var continueSec=buildContinueSection();
  if(continueSec)V.appendChild(continueSec);

  var ss=null;
  if(C.sports){
    ss=E('section','row ssec');
    var k0=E('div','tr');
    skE(k0,4);
    ss.appendChild(E('h2',null,'Eventos del día'));
    ss.appendChild(k0);
    V.appendChild(ss);
    S('&slider=1').then(function(d){
      if(token!==viewSeq)return;
      if(d.events&&d.events.length){
        ss.innerHTML='';
        sportsSlider(ss,d.events);
      }else ss.remove();
    }).catch(function(){if(ss&&ss.parentNode)ss.remove()});
  }

  R.forEach(function(r){V.appendChild(r.s)});

  defs.forEach(function(d,idx){
    G(d[1],120000,12000).then(function(j){
      if(token!==viewSeq)return;
      fill(R[idx],j.data);
    }).catch(function(){
      if(token===viewSeq&&R[idx].s.parentNode)R[idx].s.remove();
    });
  });

  genres().then(function(gList){
    if(token!==viewSeq)return;
    var topG=gList.slice(0,4);
    function loadNextGenre(i){
      if(i>=topG.length||token!==viewSeq)return;
      var g=topG[i];
      var r=row(g[1]);
      V.appendChild(r.s);
      G('all.php?type=all&genre='+enc(g[0]),180000).then(function(j){
        if(token!==viewSeq)return;
        fill(r,j.data);
        setTimeout(function(){loadNextGenre(i+1)},40);
      }).catch(function(){
        if(r.s.parentNode)r.s.remove();
        setTimeout(function(){loadNextGenre(i+1)},40);
      });
    }
    setTimeout(function(){loadNextGenre(0)},60);
  });
}

function heroInit(el,items){
  if(!items||!items.length){if(el.parentNode)el.remove();return}
  el.className='hero';
  el.innerHTML='';
  var i=0,bg=E('div','hbg'),hp=E('div','hp'),hi=new Image(),bx=E('div','hb'),
      t=E('h1'),m=E('p','hm'),o=E('p','ho'),bs=E('div','hbs'),
      pl=E('button','f pri'),mi=E('button','f','Más info'),
      dots=E('div','dots');

  pl.appendChild(ic('play'));
  pl.appendChild(E('span',null,'Ver ahora'));

  hi.decoding='async';
  hi.alt='';
  hp.appendChild(hi);
  [pl,mi].forEach(function(b){
    bs.appendChild(b);
    b.onclick=function(){go('detail',items[i])};
  });
  [t,m,o,bs].forEach(function(x){bx.appendChild(x)});
  [bg,hp,bx,dots].forEach(function(x){el.appendChild(x)});
  items.forEach(function(){dots.appendChild(E('i'))});

  function show(n){
    i=n%items.length;
    var it=items[i];
    var bgImg=it.backdrop||it.poster||'';
    if(bgImg)bg.style.backgroundImage='url("'+bgImg+'")';
    hi.src=it.poster||'';
    t.textContent=it.title;
    m.textContent=[it.year,it.type==='serie'?'Serie':'Película',(it.genres||[]).slice(0,2).join(', ')].filter(Boolean).join(' · ');
    o.textContent=(it.overview||'').slice(0,180);
    [].forEach.call(dots.children,function(d,k){d.className=k===i?'on':''});
  }
  show(0);
  heroT=setInterval(function(){show(i+1)},8000);
}

function sportsSlider(el,items){
  var h=E('div','sh'),all=E('button','f sa','Ver todos ›'),k=E('div','tr');
  all.onclick=function(){go('sports')};
  h.appendChild(E('h2',null,'Eventos del día'));
  h.appendChild(all);
  el.appendChild(h);
  el.appendChild(k);
  var frag=document.createDocumentFragment();
  items.forEach(function(it){frag.appendChild(evCard(it))});
  k.appendChild(frag);
}

/* ── Vista de Deportes ── */
function sportsV(a,token){
  var st={e:'',d:a||''},ev=[],ce=E('div','tr chips'),cd=E('div','tr chips'),grid=E('div','grid egrid');
  V.appendChild(E('div','tt','Eventos del día'));
  V.appendChild(ce);
  V.appendChild(cd);
  V.appendChild(grid);

  function mark(c,k){
    [].forEach.call(c.children,function(b){b.classList.toggle('on',b.dataset.k===k)});
  }
  function draw(){
    grid.innerHTML='';
    var filtered=ev.filter(function(x){
      return(!st.e||(st.e==='live'?x.live:x.status===st.e))&&(!st.d||x.sport_id===st.d);
    });
    if(!filtered.length){
      grid.appendChild(E('p','msg','No hay eventos para este filtro'));
      return;
    }
    var frag=document.createDocumentFragment();
    filtered.forEach(function(x){frag.appendChild(evCard(x))});
    grid.appendChild(frag);
  }
  function chip(c,l,k,fn){
    var b=E('button','f',l);
    b.dataset.k=k;
    b.onclick=function(){fn(k);mark(c,k);draw()};
    c.appendChild(b);
  }
  [['Todos',''],['En vivo','live'],['Próximos','proximo'],['Finalizados','finalizado']].forEach(function(x){
    chip(ce,x[0],x[1],function(k){st.e=k});
  });
  mark(ce,'');

  var rf=E('button','f','↻ Actualizar');
  ce.appendChild(rf);
  rf.onclick=function(){load(true)};

  function load(force){
    grid.innerHTML='';
    skE(grid,6);
    S('&limite=150'+(force?'&_='+Date.now():''),force?0:30000).then(function(d){
      if(token!==viewSeq)return;
      var rk={en_vivo:0,proximo:1,finalizado:2};
      ev=(d.events||[]).map(function(x,i){x._i=i;return x}).sort(function(a,b){
        return(a.live?0:rk[a.status]!=null?rk[a.status]:1)-(b.live?0:rk[b.status]!=null?rk[b.status]:1)||a._i-b._i;
      });
      cd.innerHTML='';
      var seen={};
      chip(cd,'Todos los deportes','',function(k){st.d=k});
      ev.forEach(function(x){
        if(x.sport_id&&!seen[x.sport_id]){
          seen[x.sport_id]=1;
          chip(cd,x.sport||x.sport_id,x.sport_id,function(k){st.d=k});
        }
      });
      if(!seen[st.d])st.d='';
      mark(cd,st.d);
      draw();
      if(force)focus(grid.querySelector('.f')||rf);
    }).catch(function(e){
      if(token!==viewSeq)return;
      grid.innerHTML='';
      grid.appendChild(E('p','msg',e.message));
    });
  }
  load(false);
}

function eventV(it){
  var d=E('div','det edet'),bg=E('div','hbg ebg'),inf=E('div','di'),bs=E('div','hbs');
  inf.appendChild(teams(it,'elg'));
  inf.appendChild(E('h1',null,it.title));
  inf.appendChild(E('p','hm'+(it.live?' live':''),[(it.league||it.sport||'').trim(),when(it)].filter(Boolean).join(' · ')));
  if(it.note)inf.appendChild(E('p','ho',it.note));
  inf.appendChild(bs);
  [bg,inf].forEach(function(x){d.appendChild(x)});
  V.appendChild(d);
  if(it.servers&&it.servers.length){
    var pl=E('button','f pri');
    pl.appendChild(ic('play'));
    pl.appendChild(E('span',null,'Reproducir'));
    pl.onclick=function(){playEv(it)};
    bs.appendChild(pl);
    var bk=E('button','f','‹ Volver');
    bk.onclick=back;
    bs.appendChild(bk);
  }else{
    inf.appendChild(E('p','ho','Todavía no hay servidores disponibles para este evento.'));
    var b2=E('button','f','‹ Volver');
    b2.onclick=back;
    bs.appendChild(b2);
  }
}

/* ── Vista Catálogo / Explorar ── */
function browse(a,token){
  var o=a&&typeof a==='object'?a:{t:a},
      type=o.t,
      st={g:o.g||'',p:1,busy:0,t:0},
      chips=E('div','tr chips'),
      grid=E('div','grid'),
      more=E('button','f mo','Cargar más');

  V.appendChild(E('div','tt',o.n||(type==='serie'?'Series':type==='pelicula'?'Películas':'Catálogo')));
  V.appendChild(chips);
  V.appendChild(grid);
  V.appendChild(more);

  function load(){
    if(st.busy)return;
    st.busy=1;
    var tk=++st.t,first=st.p===1,n=first?0:grid.children.length;
    if(first){grid.innerHTML='';skC(grid,10);more.hidden=true}
    else more.textContent='Cargando…';

    G('all.php?type='+type+'&genre='+enc(st.g)+'&page='+st.p,120000).then(function(j){
      if(tk!==st.t||token!==viewSeq)return;
      if(first)grid.innerHTML='';
      var frag=document.createDocumentFragment();
      (j.data||[]).forEach(function(it){frag.appendChild(card(it))});
      grid.appendChild(frag);
      if(first&&(!j.data||!j.data.length))grid.appendChild(E('p','msg','No hay contenido en esta categoría'));
      st.p++;
      st.busy=0;
      more.textContent='Cargar más';
      more.hidden=!(j.meta&&j.meta.has_next);
      if(n)focus(grid.children[n]);
    }).catch(function(e){
      if(tk!==st.t||token!==viewSeq)return;
      st.busy=0;
      more.textContent='Cargar más';
      if(first)grid.innerHTML='';
      toast(e.message);
    });
  }
  more.onclick=load;

  function chip(l,s2){
    var b=E('button','f',l);
    b.onclick=function(){st.t++;st.busy=0;st.g=s2;st.p=1;load()};
    chips.appendChild(b);
  }
  chip('Todos','');
  genres().then(function(g){
    if(token!==viewSeq)return;
    g.forEach(function(x){chip(x[1],x[0])});
  });
  load();
}

function nrm(x){
  x=String(x||'').toLowerCase();
  try{x=x.normalize('NFD').replace(/[\u0300-\u036f]/g,'')}catch(e){}
  return x;
}

function evMatch(it,q){
  var h=nrm([it.title,it.home,it.away,it.league,it.sport,it.note].join(' '));
  return nrm(q).split(/\s+/).filter(Boolean).every(function(w){return h.indexOf(w)>-1});
}

/* ── Vista de Búsqueda Independiente a Pantalla Completa (TV Layout: Teclado Izquierda · Resultados Derecha) ── */
function search(a,token){
  var q=(typeof a==='string'?a:(a&&a.q)||''),
      rid=0,
      lastFocusedKey=null,
      searchPage=1,
      searchBusy=false,
      searchTotalPages=1,
      searchResultTotal=0,
      searchTimer=null;

  var wrap=E('div','search-view');

  // Top nav de la vista de búsqueda
  var topNav=E('div','search-top-nav');
  var exitBtn=E('button','f search-exit-btn');
  exitBtn.appendChild(ic('arrow-left'));
  exitBtn.appendChild(E('span',null,'Volver'));
  exitBtn.onclick=function(){back()};

  var titleBadge=E('div','search-title-badge');
  titleBadge.appendChild(ic('find'));
  titleBadge.appendChild(E('span',null,'Buscador para TV'));

  topNav.appendChild(exitBtn);
  topNav.appendChild(titleBadge);
  wrap.appendChild(topNav);

  // Cuerpo: 2 Columnas (Lado Izquierdo: Teclado · Lado Derecho: Resultados)
  var body=E('div','search-body');

  // Columna Izquierda: Teclado Virtual TV
  var kbCol=E('div','search-keyboard-col');

  // Input Display Box
  var dispBox=E('div','search-display-box');
  var dispText=E('span','search-display-text');
  var cursor=E('span','search-cursor');
  dispBox.appendChild(dispText);
  dispBox.appendChild(cursor);
  kbCol.appendChild(dispBox);

  // Grilla del Teclado TV (6 columnas ordenadas)
  var kbGrid=E('div','tv-keyboard-grid');
  kbCol.appendChild(kbGrid);

  // Columna Derecha: Resultados
  var resCol=E('div','search-results-col');
  var resHead=E('div','search-results-head');
  var resTitle=E('h2',null,'Resultados de búsqueda');
  var resCount=E('span','search-results-count','');
  resHead.appendChild(resTitle);
  resHead.appendChild(resCount);
  resCol.appendChild(resHead);

  var resContent=E('div','search-results-content');
  resCol.appendChild(resContent);

  // Teclado a la IZQUIERDA y Resultados a la DERECHA
  body.appendChild(kbCol);
  body.appendChild(resCol);
  wrap.appendChild(body);
  V.appendChild(wrap);

  function updateDisplay(){
    if(!q){
      dispText.textContent='Escribe para buscar…';
      dispText.classList.add('placeholder');
    }else{
      dispText.textContent=q;
      dispText.classList.remove('placeholder');
    }
    if(cur&&cur.v==='search'){cur.a={q:q};pushURL('search',{q:q},true);}
  }

  function showEmptyPrompt(){
    resContent.innerHTML='';
    resCount.textContent='';
    var p=E('div','search-empty-prompt');
    p.appendChild(ic('find'));
    p.appendChild(E('h3',null,'Encuentra películas, series y eventos'));
    p.appendChild(E('p',null,'Escribe en el teclado virtual y presiona «Buscar» para consultar contenido.'));
    resContent.appendChild(p);
  }

  function part(title,cls,sk,loadFn,mkc){
    var sc=E('section','row'),g=E('div','grid '+cls);
    sc.appendChild(g);
    resContent.appendChild(sc);
    sk(g);
    return loadFn().then(function(items){
      if(myId!==rid||token!==viewSeq)return [];
      g.innerHTML='';
      var unique=[];
      var seen=new Set();
      (items||[]).forEach(function(it){
        var key=(it&&it.id&&String(it.id))||((it&&it.url)?String(it.url):'')||((it&&it.title)?nrm(it.title):'');
        if(!key||seen.has(key))return;
        seen.add(key);
        unique.push(it);
      });
      if(!unique.length){sc.remove();return []}
      var frag=document.createDocumentFragment();
      unique.forEach(function(it){
        var c=mkc(it);
        var origClick=c.onclick;
        c.onclick=function(){
          if(origClick)origClick();
          else go('detail',it);
        };
        frag.appendChild(c);
      });
      g.appendChild(frag);
      return unique;
    }).catch(function(){
      if(myId===rid&&sc.parentNode)sc.remove();
      return [];
    });
  }

  var myId=0;
  function bindPager(){
    var pager=E('div','search-pagination');
    var prev=E('button','f search-page-btn');
    prev.type='button';
    prev.appendChild(ic('arrow-left'));
    prev.appendChild(E('span',null,'Anterior'));
    prev.onclick=function(){runSearch(searchPage-1)};

    var status=E('span','search-page-status');
    var next=E('button','f search-page-btn');
    next.type='button';
    next.appendChild(E('span',null,'Siguiente'));
    next.appendChild(ic('arrow-right'));
    next.onclick=function(){runSearch(searchPage+1)};

    pager.appendChild(prev);
    pager.appendChild(status);
    pager.appendChild(next);
    resContent.appendChild(pager);
    return{el:pager,prev:prev,next:next,status:status};
  }

  var searchPager=bindPager();

  function runSearch(targetPage){
    var w=q.trim();
    if(w.length<2){
      toast('Escribe al menos 2 letras');
      showEmptyPrompt();
      return;
    }
    if(searchBusy)return;

    searchPage=Math.max(1,Math.min(targetPage||1,searchTotalPages));
    resContent.innerHTML='';
    resContent.classList.add('is-loading');
    var loadingPrompt=E('div','search-loading-prompt search-centered-loading');
    loadingPrompt.setAttribute('role','status');
    loadingPrompt.appendChild(E('i','spn'));
    loadingPrompt.appendChild(E('h3',null,'Buscando resultados'));
    loadingPrompt.appendChild(E('p',null,'Consultando el catálogo…'));
    resContent.appendChild(loadingPrompt);
    myId=++rid;

    searchBusy=true;
    resCount.innerHTML='';
    resCount.classList.add('is-loading');
    resCount.appendChild(E('i','spn'));
    resCount.appendChild(E('span',null,'Buscando…'));
    sgo.classList.add('is-loading');
    sgo.innerHTML='';
    sgo.appendChild(E('i','spn'));
    sgo.appendChild(E('span',null,'Buscando…'));

    function finishSearch(){
      searchBusy=false;
      clearTimeout(searchTimer);
      searchTimer=null;
      resContent.classList.remove('is-loading');
      loadingPrompt.remove();
      resCount.classList.remove('is-loading');
      sgo.classList.remove('is-loading');
      sgo.innerHTML='';
      sgo.appendChild(ic('find'));
      sgo.appendChild(E('span',null,'Buscar'));
    }

    searchTimer=setTimeout(function(){
      var ps=[];
      if(C.sports && searchPage===1){
        ps.push(part('Eventos deportivos','egrid',function(g){skE(g,4)},function(){
          return S('&limite=150',60000).then(function(d){
            return (d.events||[]).filter(function(x){return evMatch(x,w)});
          });
        },evCard));
      }
      ps.push(part('Películas y series','',function(g){skC(g,8)},function(){
        return G('search.php?per_page=24&page='+searchPage+'&q='+enc(w),60000).then(function(j){
          var meta=j.meta||{};
          searchTotalPages=Math.max(1,Number(meta.total_pages)||1);
          searchResultTotal=Number(meta.total)||0;
          return j.data||[];
        });
      },card));

      Promise.all(ps).then(function(sections){
        finishSearch();
        if(myId!==rid||token!==viewSeq)return;
        var flat=[];
        var seen=new Set();
        (sections||[]).forEach(function(items){
          (items||[]).forEach(function(it){
            var key=(it&&it.id&&String(it.id))||((it&&it.url)?String(it.url):'')||((it&&it.title)?nrm(it.title):'');
            if(!key||seen.has(key))return;
            seen.add(key);
            flat.push(it);
          });
        });
        if(!flat.length){
          resCount.textContent='0 resultados';
          resContent.innerHTML='';
          var noRes=E('div','search-empty-prompt');
          noRes.appendChild(E('h3',null,'Sin resultados'));
          noRes.appendChild(E('p',null,'No se encontraron resultados para «'+w+'». Intenta con otro término.'));
          resContent.appendChild(noRes);
          return;
        }
        resCount.textContent=searchResultTotal+(searchResultTotal===1?' resultado':' resultados');
        searchPager.status.textContent='Página '+searchPage+' de '+searchTotalPages;
        searchPager.prev.disabled=searchBusy||searchPage<=1;
        searchPager.next.disabled=searchBusy||searchPage>=searchTotalPages;
        resContent.appendChild(searchPager.el);
        var firstCard=resContent.querySelector('.row .f');
        if(firstCard)focusQuiet(firstCard);
      }).catch(function(err){
        finishSearch();
        toast(err.message||'Error en la búsqueda');
      });
    },650);
  }

  // Teclas: SOLO añade o borra caracteres; NO busca automáticamente al escribir
  function handleKey(char){
    if(char==='del'||char==='⌫'){
      q=q.slice(0,-1);
      updateDisplay();
      if(!q)showEmptyPrompt();
    }else if(char==='spc'||char==='␣'){
      q=q+' ';
      updateDisplay();
    }else if(char==='clr'||char==='✕'){
      q='';
      updateDisplay();
      showEmptyPrompt();
    }else if(char==='search'||char==='🔍'){
      runSearch();
    }else{
      q=q+char;
      updateDisplay();
    }
  }

  // Teclas ordenadas para la TV (Letras A-Z y Números 0-9)
  var keys=[
    'A','B','C','D','E','F',
    'G','H','I','J','K','L',
    'M','N','O','P','Q','R',
    'S','T','U','V','W','X',
    'Y','Z','0','1','2','3',
    '4','5','6','7','8','9'
  ];

  keys.forEach(function(k,idx){
    var b=E('button','f tv-key',k);
    b.type='button';
    b.dataset.col=idx%6;
    b.dataset.row=Math.floor(idx/6);
    b.onclick=function(){handleKey(k)};
    b.addEventListener('focus',function(){lastFocusedKey=b});
    kbGrid.appendChild(b);
  });

  // Fila de acciones del teclado (Espacio, Borrar, Limpiar, Buscar)
  var spc=E('button','f tv-key key-span-2 key-action','Espacio');
  spc.type='button';
  spc.dataset.col=0;
  spc.onclick=function(){handleKey('spc')};
  spc.addEventListener('focus',function(){lastFocusedKey=spc});
  kbGrid.appendChild(spc);

  var del=E('button','f tv-key key-danger','Borrar');
  del.type='button';
  del.title='Borrar letra';
  del.dataset.col=2;
  del.onclick=function(){handleKey('del')};
  del.addEventListener('focus',function(){lastFocusedKey=del});
  kbGrid.appendChild(del);

  var clr=E('button','f tv-key key-action','Limpiar');
  clr.type='button';
  clr.title='Limpiar texto';
  clr.dataset.col=3;
  clr.onclick=function(){handleKey('clr')};
  clr.addEventListener('focus',function(){lastFocusedKey=clr});
  kbGrid.appendChild(clr);

  // Botón Buscar con ícono SVG limpio
  var sgo=E('button','f tv-key key-span-2 key-action pri');
  sgo.type='button';
  sgo.dataset.col=4;
  sgo.appendChild(ic('find'));
  sgo.appendChild(E('span',null,'Buscar'));
  sgo.onclick=function(){runSearch(1)};
  sgo.addEventListener('focus',function(){lastFocusedKey=sgo});
  kbGrid.appendChild(sgo);

  V._searchKey=handleKey;
  V._searchRun=runSearch;
  V._searchQuery=function(){return q};
  V._searchLastKey=function(){return lastFocusedKey||kbGrid.querySelector('.tv-key')};
  V._searchResCol=resCol;

  updateDisplay();
  showEmptyPrompt();

  setTimeout(function(){
    var firstKey=kbGrid.querySelector('.tv-key');
    if(firstKey)focusQuiet(firstKey);
  },100);
}

/* ── Carga de Recomendaciones Similares ── */
function loadRecommendations(it,token){
  var genre=(it.genres&&it.genres[0])||'';
  var type=it.type==='serie'?'serie':'pelicula';

  var fetchPromise;
  if(genre){
    fetchPromise=G('all.php?type='+type+'&genre='+enc(genre),180000).then(function(j){return j.data||[]});
  }else{
    fetchPromise=G('latest.php?type='+type+'&per_page=25',180000).then(function(j){return j.data||[]});
  }

  return fetchPromise.then(function(list){
    var seen={};
    var currId=String(it.id||'');
    var currTitle=nrm(it.title||'');
    var out=[];

    (list||[]).forEach(function(item){
      if(!item||!item.title)return;
      var idStr=String(item.id||'');
      var titleNorm=nrm(item.title);
      if(idStr&&idStr===currId)return; // no recomendar el mismo contenido
      if(titleNorm===currTitle)return;
      var key=idStr||titleNorm;
      if(seen[key])return; // no duplicar
      seen[key]=true;
      out.push(item);
    });
    return out.slice(0,14);
  }).catch(function(){return[]});
}

function loadFirstEpisode(it){
  return G('episodes.php?'+ref(it)+'&per_page=10',180000).then(function(j){
    var eps=j.data||[];
    if(!eps.length)throw new Error('No hay episodios disponibles para esta serie');
    var first=eps[0];
    return{season:first.season||1,episode:first.number||1};
  });
}

/* ── Vista Detalle Independiente (SIN IMAGEN DE FONDO · HEADER FIJO) ── */
function detail(it,token){
  var d=E('div','det'),
      topNav=E('div','det-top-nav'),
      topLeft=E('div','det-top-left'),
      exitBtn=E('button','f det-back-btn'),
      navTitle=E('span','det-nav-title',it.title),
      topRight=E('div','det-top-right'),
      heroLay=E('div','det-hero-layout'),
      po=E('div','dp'),
      inf=E('div','di'),
      bs=E('div','hbs');

  // Header Fijo Simplificado: Solo Botón Volver (sin títulos ni datos informativos duplicados)
  exitBtn.appendChild(ic('arrow-left'));
  exitBtn.appendChild(E('span',null,'Volver'));
  exitBtn.onclick=requestExitDetail;
  topLeft.appendChild(exitBtn);
  topNav.appendChild(topLeft);
  d.appendChild(topNav);

  // Póster sin imagen difusa de fondo
  if(it.poster||it.backdrop){
    var m=new Image();
    m.alt='';
    attachLazyImage(po,m,it.poster||it.backdrop);
  }

  // Título
  inf.appendChild(E('h1',null,it.title));

  // Chips de metadatos (año, tipo, rating)
  var metaRow=E('div','det-meta-row');
  if(it.year){var yChip=E('span','det-meta-chip');yChip.textContent=it.year;metaRow.appendChild(yChip);}
  var typeChip=E('span','det-meta-chip type');typeChip.textContent=it.type==='serie'?'Serie':'Película';metaRow.appendChild(typeChip);
  if(it.rating){var rChip=E('span','det-meta-chip rating');rChip.innerHTML='<svg viewBox="0 0 24 24" width="12" height="12" fill="#ffd166"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg> '+Number(it.rating).toFixed(1);metaRow.appendChild(rChip);}
  inf.appendChild(metaRow);

  // Chips de géneros
  var genres=(it.genres||[]).slice(0,5);
  if(genres.length){
    var genRow=E('div','det-genres-row');
    genres.forEach(function(g){var t=E('span','det-genre-tag');t.textContent=g;genRow.appendChild(t);});
    inf.appendChild(genRow);
  }

  // Sinopsis con scroll — focusable para mando TV
  var ovDiv=E('div','f det-overview');
  ovDiv.textContent=it.overview||'';
  ovDiv.setAttribute('tabindex','0');
  ovDiv.setAttribute('role','region');
  ovDiv.setAttribute('aria-label','Sinopsis');
  // Mantener el foco en la sinopsis mientras todavía tenga texto por recorrer.
  ovDiv.addEventListener('keydown',function(e){
    var maxScroll=ovDiv.scrollHeight-ovDiv.clientHeight;
    if(e.keyCode===40&&ovDiv.scrollTop<maxScroll){
      ovDiv.scrollTop=Math.min(maxScroll,ovDiv.scrollTop+50);
      e.preventDefault();
      e.stopPropagation();
    }else if(e.keyCode===38&&ovDiv.scrollTop>0){
      ovDiv.scrollTop=Math.max(0,ovDiv.scrollTop-50);
      e.preventDefault();
      e.stopPropagation();
    }
  });
  inf.appendChild(ovDiv);

  inf.appendChild(bs);

  heroLay.appendChild(po);
  heroLay.appendChild(inf);
  d.appendChild(heroLay);
  V.appendChild(d);

  // Contenedor de cuerpo (episodios + recomendaciones)
  var detBody=E('div','det-body');

  // Botón Principal de Reproducir Moderno y Atractivo
  var pl=E('button','f pri det-play-btn');
  var plIcon=ic('play');
  var savedEpisode=it.continueEpisode||null,
      savedAt=Math.max(0,Number(it.continueAt)||0),
      savedDuration=Math.max(savedAt,Number(it.continueDuration)||0),
      hasSavedProgress=savedAt>0,
      plLabel=hasSavedProgress?(savedEpisode?'Continuar T'+savedEpisode.season+' E'+savedEpisode.number:'Continuar viendo'):
        (it.type==='serie'?'Reproducir Primer Episodio':'Reproducir Película');
  var plText=E('span',null,plLabel);
  pl.appendChild(plIcon);
  pl.appendChild(plText);

  var allSeriesEpisodes=[],episodeLoadPromise=Promise.resolve([]);

  function startTitlePlayback(resumeProgress){
    if(pl.classList.contains('is-loading'))return;
    P.watchItem=it;
    P.resumeAt=resumeProgress?savedAt:0;
    P.resumeChoice=resumeProgress?{item:it,time:savedAt,duration:savedDuration,episode:savedEpisode,shown:false}:null;
    P.watchCompleted=false;
    P.lastWatchSave=0;
    if(!resumeProgress){
      removeContinueProgress(it);
      delete it.continueAt;
      delete it.continueDuration;
      delete it.continueEpisode;
      hasSavedProgress=false;
      savedAt=0;
      savedDuration=0;
      plLabel=it.type==='serie'?'Reproducir Primer Episodio':'Reproducir Película';
    }
    pl.classList.add('is-loading');
    plIcon.innerHTML='<i class="spn"></i>';
    plText.textContent='Cargando opciones…';

    function restorePl(){
      pl.classList.remove('is-loading');
      plIcon.innerHTML=SVG.play;
      plText.textContent=plLabel;
    }

    if(it.type!=='serie'){
      P.serieContext=null;
      updateEpisodeButtons();
      servers('movie-servers.php?'+ref(it)+serverEmbedParam(),it.title,restorePl);
    }else if(savedEpisode){
      function playSavedEpisode(){
        var savedIndex=allSeriesEpisodes.findIndex(function(ep){
          return Number(ep.season)===Number(savedEpisode.season)&&Number(ep.number)===Number(savedEpisode.number);
        });
        if(savedIndex>-1){
          playSerieEpisode(it,allSeriesEpisodes,savedIndex,restorePl,resumeProgress?savedAt:0);
          return;
        }
        var ep={season:savedEpisode.season||1,number:savedEpisode.number||1,title:savedEpisode.title||''};
        P.serieContext={serie:it,allEpisodes:[ep],epIndex:0};
        updateEpisodeButtons();
        var title=it.title+' · T'+ep.season+' E'+ep.number+(ep.title?' · '+ep.title:'');
        P.resumeAt=resumeProgress?savedAt:0;
        servers('series-servers.php?'+ref(it)+'&season='+ep.season+'&episode='+ep.number+serverEmbedParam(),title,restorePl);
      }
      if(allSeriesEpisodes.length){
        playSavedEpisode();
      }else{
        plText.textContent='Buscando episodio…';
        episodeLoadPromise.then(function(){
          if(token!==viewSeq)return restorePl();
          playSavedEpisode();
        });
      }
    }else{
      if(allSeriesEpisodes&&allSeriesEpisodes.length){
        playSerieEpisode(it,allSeriesEpisodes,0,restorePl);
      }else{
        loadFirstEpisode(it).then(function(epInfo){
          P.serieContext={serie:it,allEpisodes:[{season:epInfo.season,number:epInfo.episode,title:''}],epIndex:0};
          updateEpisodeButtons();
          servers('series-servers.php?'+ref(it)+'&season='+epInfo.season+'&episode='+epInfo.episode+serverEmbedParam(),it.title+' · T'+epInfo.season+' E'+epInfo.episode,restorePl);
        }).catch(function(err){
          restorePl();
          toast(err.message||'Error al cargar episodios');
        });
      }
    }
  }
  pl.onclick=function(){
    if(pl.classList.contains('is-loading'))return;
    hasSavedProgress=false;
    savedAt=0;
    savedDuration=0;
    savedEpisode=null;
    var latestProgress=getContinueItems().find(function(entry){return entry.key===watchKey(it)});
    if(latestProgress){
      hasSavedProgress=true;
      savedAt=Math.max(0,Number(latestProgress.currentTime)||0);
      savedDuration=Math.max(savedAt,Number(latestProgress.duration)||0);
      savedEpisode=latestProgress.episode||null;
      it.continueAt=savedAt;
      it.continueDuration=savedDuration;
      it.continueEpisode=savedEpisode;
      plLabel=savedEpisode?'Continuar T'+savedEpisode.season+' E'+savedEpisode.number:'Continuar viendo';
      plText.textContent=plLabel;
    }
    startTitlePlayback(hasSavedProgress);
  };
  bs.appendChild(pl);

  // Botón Añadir a Mi Lista
  var inFav=isFav(it);
  var favBtn=E('button','f det-fav-btn'+(inFav?' in-fav':''));
  var favIcon=ic(inFav?'heart-fill':'heart');
  var favLabel=E('span',null,inFav?'En Mi Lista':'Añadir a Mi Lista');
  favBtn.appendChild(favIcon);
  favBtn.appendChild(favLabel);
  function updateFavButton(saved){
    favBtn.classList.toggle('in-fav',saved);
    favIcon.innerHTML=saved?SVG['heart-fill']:SVG.heart;
    favLabel.textContent=saved?'En Mi Lista':'Añadir a Mi Lista';
  }
  favBtn.onclick=function(){
    updateFavButton(toggleFav(it));
  };
  bs.appendChild(favBtn);

  // Para series: Slider de episodios con modal de temporadas
  var openSeasonsModal=function(){};
  if(it.type==='serie'){
    var seasonsSec=E('section','det-seasons-sec');
    var seasonsHead=E('div','det-seasons-head');
    var seasonsTitle=E('h3','det-seasons-title');
    seasonsTitle.appendChild(ic('film'));
    seasonsTitle.appendChild(E('span',null,'Episodios'));
    seasonsHead.appendChild(seasonsTitle);

    // Controles de la sección de episodios: Temporadas + Ordenar
    var seasonsControls=E('div','det-seasons-controls');

    var seasonsBtn=E('button','f det-seasons-btn');
    seasonsBtn.appendChild(ic('layers'));
    seasonsBtn.appendChild(E('span',null,'Temporada'));
    seasonsBtn.onclick=function(){openSeasonsModal();};
    seasonsControls.appendChild(seasonsBtn);

    var sortAsc=true;
    var sortBtn=E('button','f det-sort-btn');
    sortBtn.appendChild(ic('sort-asc'));
    sortBtn.appendChild(E('span',null,'Ordenar'));
    sortBtn.title='Cambiar orden de episodios';
    sortBtn.onclick=function(){
      sortAsc=!sortAsc;
      sortBtn.querySelector('.ic').innerHTML=sortAsc?SVG['sort-asc']:SVG['sort-desc'];
      var cards=[].slice.call(epList.querySelectorAll('.det-ep-card'));
      var sorted=cards.sort(function(a,b){
        var na=parseInt(a.querySelector('.det-ep-card-num').textContent.replace('Ep. ',''))||0;
        var nb=parseInt(b.querySelector('.det-ep-card-num').textContent.replace('Ep. ',''))||0;
        return sortAsc?na-nb:nb-na;
      });
      var frag=document.createDocumentFragment();
      sorted.forEach(function(c){frag.appendChild(c);});
      epList.appendChild(frag);
      setTimeout(function(){var f=epList.querySelector('.det-ep-card');if(f)focus(f);},40);
    };
    seasonsControls.appendChild(sortBtn);

    seasonsHead.appendChild(seasonsControls);
    seasonsSec.appendChild(seasonsHead);

    var epList=E('div','det-ep-slider');
    seasonsSec.appendChild(epList);
    detBody.appendChild(seasonsSec);

    // Skeletons para slider (cards)
    (function(){
      var f=document.createDocumentFragment();
      for(var si=0;si<6;si++){
        var sk=E('div','det-ep-sk');
        sk.appendChild(E('div','sk-thumb sk'));
        var skInfo=E('div','sk-info');
        skInfo.appendChild(E('div','sk-line sk'));
        skInfo.appendChild(E('div','sk-line s sk'));
        sk.appendChild(skInfo);
        f.appendChild(sk);
      }
      epList.appendChild(f);
    })();

    episodeLoadPromise=G('episodes.php?'+ref(it)+'&per_page=100',180000).then(function(j){
      var tp=Math.min(j.meta&&j.meta.total_pages||1,4),q=[];
      for(var p=2;p<=tp;p++){
        q.push(G('episodes.php?'+ref(it)+'&per_page=100&page='+p,180000).then(function(x){return x.data||[]}).catch(function(){return[]}));
      }
      return Promise.all(q).then(function(r){
        return r.reduce(function(a,b){return a.concat(b)},j.data||[]);
      });
    }).then(function(all){
      if(token!==viewSeq)return;
      // Respetar el orden real numérico de temporadas y episodios
      all.sort(function(a,b){return(a.season-b.season)||(a.number-b.number)});
      allSeriesEpisodes=all;
      var ss=[];
      all.forEach(function(e){if(ss.indexOf(e.season)<0)ss.push(e.season)});
      ss.sort(function(a,b){return a-b});

      function renderSeasonEpisodes(seasonNum){
        epList.innerHTML='';
        var seasonEps=all.filter(function(e){return e.season===seasonNum});
        var frag=document.createDocumentFragment();
        seasonEps.forEach(function(e){
          var epCard=E('button','f det-ep-card');

          // Miniatura 16:9
          var thumb=E('div','det-ep-card-thumb');
          if(e.image||it.backdrop||it.poster){
            var img=new Image();
            img.alt='';
            attachLazyImage(thumb,img,e.image||it.backdrop||it.poster);
          }
          var playOverlay=E('div','det-ep-play-overlay');
          playOverlay.innerHTML='<svg viewBox="0 0 24 24"><polygon points="6 4 19 12 6 20 6 4" fill="currentColor"/></svg>';
          thumb.appendChild(playOverlay);
          epCard.appendChild(thumb);

          // Info debajo de la miniatura
          var info=E('div','det-ep-card-info');
          info.appendChild(E('span','det-ep-card-num','Ep. '+e.number));
          info.appendChild(E('span','det-ep-card-title',e.title||('Episodio '+e.number)));
          if(e.overview){
            info.appendChild(E('p','det-ep-card-synopsis',e.overview));
          }
          epCard.appendChild(info);

          epCard.onclick=function(){
            var epIdx=all.indexOf(e);
            playSerieEpisode(it,all,epIdx>-1?epIdx:0);
          };
          frag.appendChild(epCard);
        });
        epList.appendChild(frag);
        setTimeout(function(){var f=epList.querySelector('.det-ep-card');if(f)focus(f);},60);
      }

      var currentSeason=ss[0]||null;

      // Construir modal de temporadas
      var smOverlay=E('div','seasons-modal-overlay');
      smOverlay.hidden=true;
      var smCard=E('div','seasons-modal-card');
      var smTitle=E('h3','seasons-modal-title');
      smTitle.appendChild(ic('layers'));
      smTitle.appendChild(E('span',null,'Selecciona una Temporada'));
      smCard.appendChild(smTitle);
      var smList=E('div','seasons-modal-list');

      function closeSeasonModal(){smOverlay.hidden=true;focus(seasonsBtn);}

      ss.forEach(function(seasonNum){
        var item=E('button','f seasons-modal-item'+(seasonNum===currentSeason?' on':''),'Temporada '+seasonNum);
        item.onclick=function(){
          smList.querySelectorAll('.seasons-modal-item').forEach(function(i){i.classList.remove('on')});
          item.classList.add('on');
          currentSeason=seasonNum;
          seasonsTitle.lastChild.textContent='T'+seasonNum+' · Episodios';
          renderSeasonEpisodes(seasonNum);
          closeSeasonModal();
        };
        smList.appendChild(item);
      });

      var smClose=E('button','seasons-modal-close f','Cancelar');
      smClose.onclick=closeSeasonModal;
      smCard.appendChild(smList);
      smCard.appendChild(smClose);
      smOverlay.appendChild(smCard);
      smOverlay.onclick=function(e){if(e.target===smOverlay)closeSeasonModal();};
      document.body.appendChild(smOverlay);

      openSeasonsModal=function(){
        smOverlay.hidden=false;
        setTimeout(function(){var f=smList.querySelector('.seasons-modal-item.on')||smList.querySelector('.seasons-modal-item');if(f)focus(f);},60);
      };

      if(ss.length){
        renderSeasonEpisodes(ss[0]);
      }else{
        epList.innerHTML='';
        epList.appendChild(E('p','msg','Sin episodios disponibles'));
      }
      return all;
    }).catch(function(e){
      if(token!==viewSeq)return;
      epList.innerHTML='';
      epList.appendChild(E('p','msg',e.message));
      return[];
    });
  }

  // Apartado de recomendaciones similares
  var recSec=E('section','det-recommendations');
  var recHead=E('h2');
  recHead.appendChild(ic('sparkles'));
  recHead.appendChild(E('span',null,'Recomendaciones similares'));
  var recRow=E('div','tr');
  recSec.appendChild(recHead);
  recSec.appendChild(recRow);
  detBody.appendChild(recSec);
  d.appendChild(detBody);
  skC(recRow,6);

  loadRecommendations(it,token).then(function(items){
    if(token!==viewSeq)return;
    recRow.innerHTML='';
    if(!items||!items.length){
      recSec.remove();
      return;
    }
    var frag=document.createDocumentFragment();
    items.forEach(function(rec){
      var c=card(rec);
      c.onclick=function(){
        // Actualizar detalles con el contenido recomendado de forma independiente
        go('detail',rec);
      };
      frag.appendChild(c);
    });
    recRow.appendChild(frag);
  }).catch(function(){
    if(recSec.parentNode)recSec.remove();
  });

  setTimeout(function(){
    if(savedAt>0)pl.click();
    else focus(pl||exitBtn);
  },savedAt>0?160:100);
}

/* ── Control de Episodios de Series (Anterior / Siguiente estilo Netflix) ── */
function playSerieEpisode(serie,allEpisodes,epIndex,onComplete,resumeAt){
  if(!allEpisodes||!allEpisodes.length||epIndex<0||epIndex>=allEpisodes.length)return;
  var ep=allEpisodes[epIndex];
  P.watchItem=serie;
  P.resumeAt=Math.max(0,Number(resumeAt)||0);
  P.watchCompleted=false;
  P.lastWatchSave=0;
  if(!P.resumeAt)removeContinueProgress(serie);
  P.serieContext={
    serie:serie,
    allEpisodes:allEpisodes,
    epIndex:epIndex
  };
  updateEpisodeButtons();
  var title=serie.title+' · T'+ep.season+' E'+ep.number+(ep.title?' · '+ep.title:'');
  showLoading('Cargando T'+ep.season+' E'+ep.number+'…');
  servers('series-servers.php?'+ref(serie)+'&season='+ep.season+'&episode='+ep.number+serverEmbedParam(),title,onComplete);
}

function updateEpisodeButtons(){
  var ctx=P.serieContext;
  var isSerie=!!(ctx&&ctx.allEpisodes&&ctx.allEpisodes.length);
  if(!isSerie){
    if(PB_PREV_EP){PB_PREV_EP.hidden=true;PB_PREV_EP.disabled=true}
    if(PB_NEXT_EP){PB_NEXT_EP.hidden=true;PB_NEXT_EP.disabled=true}
    if(PB_EP_SUBTITLE)PB_EP_SUBTITLE.textContent='';
    return;
  }
  var hasPrev=ctx.epIndex>0;
  var hasNext=ctx.epIndex<ctx.allEpisodes.length-1;
  var currEp=ctx.allEpisodes[ctx.epIndex];

  if(PB_PREV_EP){
    PB_PREV_EP.hidden=!hasPrev;
    PB_PREV_EP.disabled=!hasPrev;
    if(hasPrev){
      var prevEp=ctx.allEpisodes[ctx.epIndex-1];
      PB_PREV_EP.title='Capítulo anterior: T'+prevEp.season+' E'+prevEp.number+(prevEp.title?' · '+prevEp.title:'');
    }
  }
  if(PB_NEXT_EP){
    PB_NEXT_EP.hidden=!hasNext;
    PB_NEXT_EP.disabled=!hasNext;
    if(hasNext){
      var nextEp=ctx.allEpisodes[ctx.epIndex+1];
      PB_NEXT_EP.title='Siguiente capítulo: T'+nextEp.season+' E'+nextEp.number+(nextEp.title?' · '+nextEp.title:'');
    }
  }
  if(PB_EP_SUBTITLE){
    PB_EP_SUBTITLE.textContent='T'+currEp.season+' E'+currEp.number+(currEp.title?' · '+currEp.title:'');
  }
}

function playPrevEp(){
  var ctx=P.serieContext;
  if(ctx&&ctx.epIndex>0){
    toast('Cargando capítulo anterior…');
    playSerieEpisode(ctx.serie,ctx.allEpisodes,ctx.epIndex-1);
  }
}

function playNextEp(){
  var ctx=P.serieContext;
  if(ctx&&ctx.epIndex<ctx.allEpisodes.length-1){
    var nextEp=ctx.allEpisodes[ctx.epIndex+1];
    toast('Siguiente episodio: T'+nextEp.season+' E'+nextEp.number+'…');
    playSerieEpisode(ctx.serie,ctx.allEpisodes,ctx.epIndex+1);
  }
}

if(PB_PREV_EP)PB_PREV_EP.onclick=playPrevEp;
if(PB_NEXT_EP)PB_NEXT_EP.onclick=playNextEp;

/* ── Sistema de Selección: Solicita Idioma ANTES de mostrar el reproductor ── */
function servers(path,title,onComplete){
  showLoading(title?'Buscando servidores para '+title+'…':'Cargando opciones de reproducción…');
  svModalOpener=document.activeElement;
  G(path,30000).then(function(j){
    hideLoading();
    if(onComplete)onComplete();
    var d=j.data||{},
        L=d.languages||(d.episodes&&d.episodes[0]&&d.episodes[0].languages)||{},
        validLangs={},
        keys=[];

    Object.keys(L).forEach(function(k){
      var sList=[];
      (L[k]||[]).forEach(function(s,idx){
        sList.push({
          l:k,
          p:s.provider||('Servidor '+(idx+1)),
          q:s.quality||'HD',
          u:s.url,
          d:s.direct_stream,
          idx:idx
        });
      });
      sList.sort(function(a,b){return(b.d?1:0)-(a.d?1:0)});
      if(sList.length){
        validLangs[k]=sList;
        keys.push(k);
      }
    });

    if(!keys.length)return toast('No hay servidores disponibles para este contenido');

    var rk={Latino:0,Castellano:1,Subtitulado:2,English:3,'Inglés':3};
    keys.sort(function(a,b){
      var x=rk[a]!=null?rk[a]:9,y=rk[b]!=null?rk[b]:9;
      return x-y||(a<b?-1:1);
    });

    SV_DATA.title=title;
    SV_DATA.langs=validLangs;
    SV_DATA.langKeys=keys;
    SV_DATA.selectedLang=null;

    P.list=[];
    P.i=-1;
    P.t=title;
    document.getElementById('pt').textContent=title;
    updateEpisodeButtons();

    // NO mostrar el reproductor todavía: solicitar idioma antes
    PL.hidden=true;
    showLangPicker(false);
  }).catch(function(e){
    hideLoading();
    if(onComplete)onComplete();
    toast(e.message||'Error al cargar servidores');
  });
}

function showLangPicker(insidePlayer){
  if(!SV_MODAL||!SV)return;
  SV.innerHTML='';

  var topNav=E('div','sv-top-nav');
  var closeBtn=E('button','f sv-back-btn');
  closeBtn.appendChild(ic('arrow-left'));
  closeBtn.appendChild(E('span',null,insidePlayer?'Volver al video':'Cancelar'));
  closeBtn.onclick=closeSvModal;
  topNav.appendChild(closeBtn);
  SV.appendChild(topNav);

  SV.appendChild(E('h3',null,'Elige un idioma de audio'));
  if(SV_DATA.title){
    SV.appendChild(E('p','sv-sub',SV_DATA.title));
  }

  var firstBtn=null;
  SV_DATA.langKeys.forEach(function(lang){
    var list=SV_DATA.langs[lang]||[];
    var b=E('button','f pick lang-pick'+(SV_DATA.selectedLang===lang?' on':''));
    b.appendChild(ic('globe'));
    b.appendChild(E('b',null,lang));
    b.appendChild(E('span','tag ok',list.length+(list.length===1?' servidor':' servidores')));
    b.appendChild(ic('arrow-right'));
    b.onclick=function(){
      chooseLang(lang,insidePlayer);
    };
    SV.appendChild(b);
    if(!firstBtn)firstBtn=b;
  });

  SV_MODAL.hidden=false;
  lockSvScroll();
  focus(SV.querySelector('.on')||firstBtn||closeBtn);
}

function chooseLang(lang,insidePlayer){
  SV_DATA.selectedLang=lang;
  P.list=SV_DATA.langs[lang]||[];
  P.on=true;
  P.t=SV_DATA.title;

  if(PB_LANG_LABEL){
    PB_LANG_LABEL.textContent=lang+' · Auto';
  }

  closeSvModal();
  PL.hidden=false;
  status('');
  updateEpisodeButtons();
  // SIEMPRE ACTIVO EL AUTOMÁTICO: se reproduce de inmediato con el mejor servidor para ese idioma
  startS(0);
}

/* ── Menú para Cambiar Idioma o Servidor desde el Reproductor ── */
function openPlayerMenu(){
  if(!P.on||!SV_MODAL||!SV)return;
  svModalOpener=document.activeElement;
  SV.innerHTML='';

  var topNav=E('div','sv-top-nav');
  var backVid=E('button','f sv-back-btn');
  backVid.appendChild(ic('arrow-left'));
  backVid.appendChild(E('span',null,'Volver al video'));
  backVid.onclick=closeSvModal;
  topNav.appendChild(backVid);
  SV.appendChild(topNav);

  SV.appendChild(E('h3',null,'Audio y Servidores'));
  if(SV_DATA.title){
    SV.appendChild(E('p','sv-sub',SV_DATA.title));
  }

  // Opción 1: Cambiar idioma
  var langBtn=E('button','f pick');
  langBtn.appendChild(ic('globe'));
  langBtn.appendChild(E('b',null,'Cambiar idioma de audio'));
  langBtn.appendChild(E('span','tag ok',SV_DATA.selectedLang||'Seleccionar'));
  langBtn.appendChild(ic('arrow-right'));
  langBtn.onclick=function(){
    showLangPicker(true);
  };
  SV.appendChild(langBtn);

  // Opción 2: Automático (Mejor servidor)
  var autoBtn=E('button','f pick auto'+(P.i===0?' on':''));
  autoBtn.appendChild(ic('zap'));
  autoBtn.appendChild(E('b',null,'Automático (Mejor servidor)'));
  autoBtn.appendChild(E('span','tag ok','Recomendado'));
  autoBtn.onclick=function(){
    if(PB_LANG_LABEL)PB_LANG_LABEL.textContent=(SV_DATA.selectedLang||'')+' · Auto';
    closeSvModal();
    startS(0);
  };
  SV.appendChild(autoBtn);

  // Lista de servidores para el idioma actual
  var sList=P.list||[];
  if(sList.length>1){
    SV.appendChild(E('h4','sv-section-title','Servidores disponibles ('+(SV_DATA.selectedLang||'')+')'));
    sList.forEach(function(s,idx){
      var b=E('button','f pick'+(idx===P.i?' on':''));
      b.appendChild(E('b',null,s.p));
      b.appendChild(E('span','tag',s.q||'HD'));
      b.appendChild(E('span','tag'+(s.d||s.h?' ok':''),s.d||s.h?'Directo':'Embed'));
      b.onclick=function(){
        if(PB_LANG_LABEL)PB_LANG_LABEL.textContent=(SV_DATA.selectedLang||'')+' · '+s.p;
        closeSvModal();
        startS(idx);
      };
      SV.appendChild(b);
    });
  }

  SV_MODAL.hidden=false;
  lockSvScroll();
  focus(langBtn);
}

function playEv(it){
  svModalOpener=document.activeElement;
  P.watchItem=null;
  P.resumeAt=0;
  P.watchCompleted=true;
  var l={};
  var eventServers=(it.servers||[]).filter(function(s){
    return C.includeEmbeds||!!s.hls||/\.(m3u8|mp4)(?:[?#]|$)/i.test(String(s.url||''));
  });
  eventServers.forEach(function(s,idx){
    var langName=(s.langs&&s.langs[0])?s.langs[0]:'Español';
    if(!l[langName])l[langName]=[];
    var directUrl=s.hls||(/\.(m3u8|mp4)(?:[?#]|$)/i.test(String(s.url||''))?s.url:null);
    l[langName].push({
      l:langName,
      p:s.name||('Servidor '+(idx+1)),
      q:s.quality||'HD',
      u:C.includeEmbeds?(s.embed||s.url||s.hls):(directUrl||''),
      h:directUrl,
      d:null,
      idx:idx
    });
  });

  var keys=Object.keys(l);
  if(!keys.length)return toast(C.includeEmbeds?'Este evento no tiene servidores':'Este evento no tiene enlaces directos disponibles');

  keys.forEach(function(k){
    l[k].sort(function(a,b){return(b.h?1:0)-(a.h?1:0)});
  });

  SV_DATA.title=it.title;
  SV_DATA.langs=l;
  SV_DATA.langKeys=keys;
  SV_DATA.selectedLang=null;

  P.serieContext=null;
  updateEpisodeButtons();
  P.list=[];
  P.i=-1;
  P.t=it.title;
  document.getElementById('pt').textContent=it.title;

  PL.hidden=true;
  showLangPicker(false);
}

/* ── Reproductor de Video y HLS Optimizado con Auto-Fallback ── */
var HLS_CONFIG={
  maxBufferLength:20,
  maxMaxBufferLength:40,
  maxBufferSize:35*1000*1000,
  backBufferLength:15,
  enableWorker:true,
  lowLatencyMode:false
};
var hlsP,hlsQ=[];
function hlsF(){var q=hlsQ;hlsQ=[];q.forEach(function(f){f()})}
function hls(cb){
  if(window.Hls)return cb();
  hlsQ.push(cb);
  if(hlsP)return;
  var x=hlsP=document.createElement('script');
  x.src='https://cdn.jsdelivr.net/npm/hls.js@1.5.17/dist/hls.min.js';
  x.addEventListener('load',hlsF);
  x.addEventListener('error',function(){hlsP=null;x.remove();hlsF()});
  document.head.appendChild(x);
}
function status(m){ST.textContent=m;ST.className=/^Cargando/.test(m)?'ld':'';ST.hidden=!m}
function stopM(){
  clearTimeout(serverTimeoutTimer);
  if(P.h){try{P.h.destroy()}catch(e){}P.h=null}
  VD.pause();
  VD.removeAttribute('src');
  while(VD.firstChild)VD.removeChild(VD.firstChild);
  VD.load();
  IF.removeAttribute('src');
  if(IF.parentNode)IF.parentNode.removeChild(IF);
}

function attachPlayerIframe(){
  if(!IF.parentNode)PL.insertBefore(IF,PB);
}

function startS(i){
  var s=P.list[i];
  stopM();

  if(!s){
    status('No se pudo reproducir ningún servidor disponible en '+(SV_DATA.selectedLang||'este idioma')+'. Pulsa ▲ para cambiar.');
    return;
  }
  P.i=i;
  status('Cargando '+s.p+' · '+(s.l||SV_DATA.selectedLang||'')+'…');

  if(PB_LANG_LABEL){
    PB_LANG_LABEL.textContent=(s.l||SV_DATA.selectedLang||'Audio')+' · '+(i===0?'Auto ('+s.p+')':s.p);
  }

  // Timeout automático: si no reproduce en 12s, salta al siguiente servidor de ese idioma
  serverTimeoutTimer=setTimeout(function(){
    if(P.on&&P.i===i&&VD.paused&&VD.currentTime===0){
      toast(s.p+' no respondió. Probando siguiente servidor…');
      nextS(i);
    }
  },12000);

  if(s.h)return playH(s,i);
  if(!s.d){
    IF.hidden=false;
    VD.hidden=true;
    P.resumeChoice=null;
    P.resumeAt=0;
    attachPlayerIframe();
    IF.src=s.u;
    status('');
    clearTimeout(serverTimeoutTimer);
    return;
  }
  IF.hidden=true;
  VD.hidden=false;
  fetch(s.d.replace('&redirect=1','')).then(function(r){
    if(!r.ok)throw new Error('HTTP '+r.status);
    return r.json();
  }).then(function(j){
    if(!j.ok||!j.stream)throw new Error('Stream no disponible');
    if(!P.on||P.i!==i||PL.hidden)return;
    (j.subtitles||[]).forEach(function(x,k){
      var tr=E('track');
      tr.kind='subtitles';
      tr.label=x.label;
      tr.src=x.url;
      if(k===0&&/esp|spa|lat/i.test(x.label))tr.default=true;
      VD.appendChild(tr);
    });
    if(j.type==='hls'&&!VD.canPlayType('application/vnd.apple.mpegurl')){
      hls(function(){
        if(!P.on||P.i!==i||PL.hidden)return;
        if(!window.Hls||!Hls.isSupported())return nextS(i);
        P.h=new Hls(HLS_CONFIG);
        P.h.loadSource(j.stream);
        P.h.attachMedia(VD);
        P.h.on(Hls.Events.ERROR,function(e,x){
          if(x&&x.fatal){
            toast(s.p+' falló. Probando siguiente servidor…');
            nextS(i);
          }
        });
        requestVideoPlayback();
      });
    }else{
      VD.src=j.stream;
      requestVideoPlayback();
    }
  }).catch(function(){
    toast('Servidor '+(i+1)+' ('+s.p+') no disponible. Probando siguiente…');
    nextS(i);
  });
}

function nextS(i){
  clearTimeout(serverTimeoutTimer);
  if(!P.on)return;
  if(P.list&&i+1<P.list.length){
    var nextServer=P.list[i+1];
    toast('Probando siguiente: '+nextServer.p+'…');
    startS(i+1);
  }else{
    status('No se pudo reproducir ningún servidor disponible en '+(SV_DATA.selectedLang||'este idioma')+'. Pulsa ▲ para cambiar.');
  }
}

function fail(i){
  var s=P.list[i];
  if(!P.on||P.i!==i)return;
  if(s&&s.h&&s.u&&!s.fb){
    s.fb=1;
    stopM();
    IF.hidden=false;
    VD.hidden=true;
    attachPlayerIframe();
    IF.src=s.u;
    status('');
    return;
  }
  nextS(i);
}

function playH(s,i){
  IF.hidden=true;
  VD.hidden=false;
  if(VD.canPlayType('application/vnd.apple.mpegurl')){
    VD.src=s.h;
    requestVideoPlayback();
    return;
  }
  hls(function(){
    if(P.i!==i||!P.on)return;
    if(!window.Hls||!Hls.isSupported())return fail(i);
    var h=P.h=new Hls(HLS_CONFIG),r=0;
    h.loadSource(s.h);
    h.attachMedia(VD);
    h.on(Hls.Events.MANIFEST_PARSED,requestVideoPlayback);
    h.on(Hls.Events.ERROR,function(e,x){
      if(!x||!x.fatal)return;
      if(x.type==='networkError'&&r++<2)h.startLoad();
      else if(x.type==='mediaError'&&r++<2)h.recoverMediaError();
      else{
        toast(s.p+' falló. Probando siguiente servidor…');
        nextS(i);
      }
    });
  });
}

function closeP(){
  saveContinueProgress(true);
  P.on=false;
  P.resumeChoice=null;
  seekTarget=null;
  clearTimeout(serverTimeoutTimer);
  clearTimeout(seekTimer);
  clearTimeout(seekBadgeTimer);
  if(SEEK_BADGE)SEEK_BADGE.hidden=true;
  stopM();
  PL.hidden=true;
  PL.classList.remove('is-resume-prompt');
  if(RESUME_PROMPT)RESUME_PROMPT.hidden=true;
  updateContinueSection();
  closeSvModal();
  status('');
  if(cur&&cur.v==='detail'){
    var playBtn=document.querySelector('.det-play-btn');
    if(playBtn)focus(playBtn);
  }
}

window.addEventListener('pagehide',function(){
  if(P.on)closeP();
});

function showB(autoFocus){
  PB.classList.remove('h');
  clearTimeout(pbT);
  pbT=setTimeout(function(){
    PB.classList.add('h');
    if(document.activeElement&&PB.contains(document.activeElement)){
      try{document.activeElement.blur()}catch(e){}
    }
  },4000);
  if(autoFocus&&PB_PLAY_BTN&&(!document.activeElement||!PB.contains(document.activeElement))){
    focus(PB_PLAY_BTN);
  }
}

/* ── Optimización de Adelantado / Retroceso Fluido (Debounced Seeking) ── */
var seekTarget=null,seekTimer=null,seekBadgeTimer=null;

function fmtTime(sec){
  if(!isFinite(sec)||isNaN(sec)||sec<0)return'0:00';
  sec=Math.floor(sec);
  var m=Math.floor(sec/60),s=('0'+(sec%60)).slice(-2);
  if(m>=60){
    var h=Math.floor(m/60);
    m=('0'+(m%60)).slice(-2);
    return h+':'+m+':'+s;
  }
  return m+':'+s;
}

function updateProgressBar(curr,dur){
  var pg=document.getElementById('pg'),tm=document.getElementById('tm');
  var lv=!isFinite(dur)||dur<=0;
  var percent=lv?100:dur?Math.min(100,(curr/dur)*100):0;
  if(pg)pg.style.width=percent+'%';
  if(tm)tm.textContent=lv?'● EN VIVO':fmtTime(curr)+' / '+fmtTime(dur);
  if(PROGRESS_BAR){
    PROGRESS_BAR.setAttribute('aria-valuenow',String(Math.round(percent)));
    PROGRESS_BAR.setAttribute('aria-valuetext',lv?'En vivo':fmtTime(curr)+' de '+fmtTime(dur));
  }
}

function setPlayControl(playing){
  if(PB_PLAY_ICON)PB_PLAY_ICON.innerHTML=playing?SVG.pause:SVG.play;
  if(PB_PLAY_BTN){
    PB_PLAY_BTN.setAttribute('aria-label',playing?'Pausar':'Reproducir');
    PB_PLAY_BTN.title=playing?'Pausar':'Reproducir';
  }
}

function performSeek(delta){
  if(!P.on||!VD||VD.hidden)return;
  var d=VD.duration||0;
  if(!isFinite(d)||d<=0)return;

  showB();
  if(seekTarget===null){
    seekTarget=VD.currentTime||0;
  }
  seekTarget=Math.max(0,Math.min(d-1,seekTarget+delta));

  // Actualización inmediata visual sin trabar la decodificación de video
  updateProgressBar(seekTarget,d);

  if(SEEK_BADGE){
    SEEK_BADGE.textContent=(delta>0?'+10s':'-10s')+'  ('+fmtTime(seekTarget)+')';
    SEEK_BADGE.hidden=false;
    clearTimeout(seekBadgeTimer);
  }

  // Debounced seeking real para evitar congelamiento de HLS y reproducción
  clearTimeout(seekTimer);
  seekTimer=setTimeout(function(){
    if(seekTarget!==null&&VD){
      try{VD.currentTime=seekTarget}catch(e){}
      seekTarget=null;
    }
    seekBadgeTimer=setTimeout(function(){
      if(SEEK_BADGE)SEEK_BADGE.hidden=true;
    },650);
  },240);
}

function togglePlayPause(){
  if(!P.on)return;
  if(!VD.hidden){
    if(VD.paused){
      VD.play().catch(function(){});
      setPlayControl(true);
    }else{
      VD.pause();
      setPlayControl(false);
    }
    showB();
  }
}

if(PB_RW_BTN)PB_RW_BTN.onclick=function(){performSeek(-10)};
if(PB_FF_BTN)PB_FF_BTN.onclick=function(){performSeek(10)};
if(PB_PLAY_BTN)PB_PLAY_BTN.onclick=togglePlayPause;
if(PB_CLOSE_BTN)PB_CLOSE_BTN.onclick=closeP;
if(PB_LANG_BTN)PB_LANG_BTN.onclick=openPlayerMenu;

/* ── Barra de Progreso Interactiva: clic, arrastre y touch ── */
(function(){
  var BAR=document.getElementById('progressBar');
  var PG=document.getElementById('pg');
  var TT=document.getElementById('barTooltip');
  var dragging=false;

  function pctFromX(e){
    var rect=BAR.getBoundingClientRect();
    var clientX=e.touches?e.touches[0].clientX:e.clientX;
    return Math.max(0,Math.min(1,(clientX-rect.left)/rect.width));
  }

  function seekToPct(pct){
    if(!P.on||!VD||VD.hidden)return;
    var dur=VD.duration||0;
    if(!isFinite(dur)||dur<=0)return;
    var t=pct*dur;
    seekTarget=Math.max(0,Math.min(dur-1,t));
    updateProgressBar(seekTarget,dur);
    if(PG)PG.style.width=(pct*100)+'%';
    clearTimeout(seekTimer);
    seekTimer=setTimeout(function(){
      if(seekTarget!==null&&VD){
        try{VD.currentTime=seekTarget}catch(ex){}
        seekTarget=null;
      }
    },200);
  }

  function updateTooltip(pct){
    if(!TT)return;
    var dur=VD&&VD.duration||0;
    var t=isFinite(dur)&&dur>0?pct*dur:0;
    TT.textContent=fmtTime(t);
    TT.style.left=(pct*100)+'%';
  }

  if(BAR){
    // Mouse events
    BAR.addEventListener('mousedown',function(e){
      if(!P.on)return;
      e.preventDefault();
      dragging=true;
      BAR.classList.add('dragging');
      showB();
      var pct=pctFromX(e);
      updateTooltip(pct);
      seekToPct(pct);
    });
    document.addEventListener('mousemove',function(e){
      if(!dragging||!P.on)return;
      var pct=pctFromX(e);
      updateTooltip(pct);
      seekToPct(pct);
    });
    document.addEventListener('mouseup',function(){
      if(!dragging)return;
      dragging=false;
      BAR.classList.remove('dragging');
    });
    // Hover tooltip (sin dragging)
    BAR.addEventListener('mousemove',function(e){
      if(dragging)return;
      var pct=pctFromX(e);
      updateTooltip(pct);
    });
    // Touch events
    BAR.addEventListener('touchstart',function(e){
      if(!P.on)return;
      dragging=true;
      BAR.classList.add('dragging');
      showB();
      var pct=pctFromX(e);
      updateTooltip(pct);
      seekToPct(pct);
    },{passive:true});
    BAR.addEventListener('touchmove',function(e){
      if(!dragging||!P.on)return;
      var pct=pctFromX(e);
      updateTooltip(pct);
      seekToPct(pct);
    },{passive:true});
    BAR.addEventListener('touchend',function(){
      dragging=false;
      BAR.classList.remove('dragging');
    });
    // Accesibilidad teclado (Izq/Der sobre la barra)
    BAR.addEventListener('keydown',function(e){
      if(!P.on)return;
      if(e.keyCode===37){performSeek(-10);e.preventDefault();e.stopPropagation();}
      else if(e.keyCode===39){performSeek(10);e.preventDefault();e.stopPropagation();}
    });
  }
})();

/* ── Gestos Táctiles en el Reproductor (swipe ← → pausa/seek, doble tap zona) ── */
(function(){
  var touchStartX=0,touchStartY=0,touchStartT=0,lastTap=0,lastTapX=0;
  var seekPerSwipePx=4; // segundos por pixel deslizado

  PL.addEventListener('touchstart',function(e){
    if(!P.on)return;
    var t=e.touches[0];
    touchStartX=t.clientX;
    touchStartY=t.clientY;
    touchStartT=VD&&!VD.hidden?VD.currentTime:0;
  },{passive:true});

  PL.addEventListener('touchend',function(e){
    if(!P.on)return;
    var t=e.changedTouches[0];
    var dx=t.clientX-touchStartX;
    var dy=t.clientY-touchStartY;
    var now=Date.now();

    // Doble tap para adelantar/retroceder (zona izquierda -10s, zona derecha +10s)
    if(Math.abs(dx)<20&&Math.abs(dy)<20){
      var elapsed=now-lastTap;
      var xDiff=Math.abs(t.clientX-lastTapX);
      if(elapsed<340&&xDiff<60){
        var half=PL.offsetWidth/2;
        performSeek(t.clientX<half?-10:10);
        if(SEEK_BADGE){
          SEEK_BADGE.textContent=(t.clientX<half?'-10s (doble tap)':'+10s (doble tap)');
          SEEK_BADGE.hidden=false;
          clearTimeout(seekBadgeTimer);
          seekBadgeTimer=setTimeout(function(){SEEK_BADGE.hidden=true},900);
        }
        lastTap=0;
        return;
      }
      lastTap=now;
      lastTapX=t.clientX;
      showB(true);
      return;
    }

    // Swipe horizontal para seek continuo (solo si no fue scroll vertical)
    if(Math.abs(dx)>50&&Math.abs(dx)>Math.abs(dy)*1.5&&!VD.hidden){
      var dur=VD.duration||0;
      if(isFinite(dur)&&dur>0){
        var delta=dx*seekPerSwipePx;
        performSeek(delta);
      }
    }
  });
})();

VD.addEventListener('playing',function(){
  clearTimeout(serverTimeoutTimer);
  status('');
  setPlayControl(true);
  showB();
});
VD.addEventListener('pause',function(){
  saveContinueProgress(true);
  setPlayControl(false);
});
VD.addEventListener('loadedmetadata',function(){
  if(P.resumeChoice){
    showResumePrompt();
    return;
  }
  if(!P.on||VD.hidden||!P.resumeAt||!isFinite(VD.duration)||VD.duration<=0)return;
  var target=Math.min(P.resumeAt,Math.max(0,VD.duration-2));
  P.resumeAt=0;
  try{
    VD.currentTime=target;
    updateProgressBar(target,VD.duration);
  }catch(e){}
});
VD.addEventListener('waiting',function(){status('Cargando…')});
VD.addEventListener('error',function(){if(P.on)fail(P.i)});
VD.addEventListener('ended',function(){
  P.watchCompleted=true;
  if(P.watchItem){
    removeContinueProgress(P.watchItem);
    if(cur&&cur.v==='detail'&&cur.a&&sameFavorite(cur.a,P.watchItem)){
      delete cur.a.continueAt;
      delete cur.a.continueEpisode;
      pushURL('detail',cur.a,true);
    }
  }
  if(P.serieContext&&P.serieContext.epIndex<P.serieContext.allEpisodes.length-1){
    toast('Reproduciendo siguiente episodio…');
    setTimeout(playNextEp,1200);
  }
});
VD.addEventListener('timeupdate',function(){
  if(VD.currentTime>0)clearTimeout(serverTimeoutTimer);
  if(seekTarget!==null)return;
  var d=VD.duration||0,c=VD.currentTime||0;
  updateProgressBar(c,d);
  saveContinueProgress(false);
});
window.addEventListener('pagehide',function(){saveContinueProgress(true)});

/* ── Menú Hamburguesa para Géneros y Eventos ── */
function closeHamb(){
  if(!HAMB||HAMB.hidden)return;
  HAMB.hidden=true;
  if(hambOpener&&hambOpener.focus){
    try{hambOpener.focus({preventScroll:true})}catch(e){hambOpener.focus()}
  }
}

function openHamb(type){
  hambOpener=document.activeElement;
  HAMB.hidden=false;
  HB_BODY.innerHTML='';

  if(type==='genres'){
    HB_TITLE.textContent='Géneros';
    HB_ICON.innerHTML=SVG.menu;
    var grid=E('div','hamb-grid');
    HB_BODY.appendChild(grid);
    skC(grid,8);
    genres().then(function(gList){
      grid.innerHTML='';
      var frag=document.createDocumentFragment();
      gList.forEach(function(x){
        var b=E('button','f hamb-item');
        b.appendChild(ic(getGenreIcon(x[1])));
        b.appendChild(E('span',null,x[1]));
        b.onclick=function(){
          closeHamb();
          navTo('browse',{t:'all',g:x[0],n:x[1]});
        };
        frag.appendChild(b);
      });
      grid.appendChild(frag);
      focus(grid.querySelector('.f'));
    });
  }else{
    HB_TITLE.textContent='Eventos en vivo';
    HB_ICON.innerHTML=SVG.live;
    var topRow=E('div','tr chips'),
        listGrid=E('div','grid egrid');
    HB_BODY.appendChild(topRow);
    HB_BODY.appendChild(listGrid);
    skE(listGrid,4);

    var allBtn=E('button','f','Ver agenda completa ›');
    allBtn.onclick=function(){
      closeHamb();
      navTo('sports');
    };
    topRow.appendChild(allBtn);

    S('&limite=150',30000).then(function(d){
      listGrid.innerHTML='';
      var events=d.events||[];
      if(!events.length){
        listGrid.appendChild(E('p','msg','No hay eventos en vivo disponibles en este momento.'));
        return;
      }
      var frag=document.createDocumentFragment();
      events.slice(0,18).forEach(function(ev){
        var cardEl=evCard(ev);
        var origClick=cardEl.onclick;
        cardEl.onclick=function(){
          closeHamb();
          if(origClick)origClick();
        };
        frag.appendChild(cardEl);
      });
      listGrid.appendChild(frag);
      focus(listGrid.querySelector('.f')||allBtn);
    }).catch(function(err){
      listGrid.innerHTML='';
      listGrid.appendChild(E('p','msg',err.message||'Error al cargar eventos'));
    });
  }
}

if(HB_BG)HB_BG.onclick=closeHamb;
if(HB_CLOSE)HB_CLOSE.onclick=closeHamb;

/* ── Navegación Espacial (D-Pad para Smart TV y controles remotos) ── */
function move(d){
  var root=(RESUME_PROMPT&&!RESUME_PROMPT.hidden)?RESUME_PROMPT:(favRemoveModal&&!favRemoveModal.hidden)?favRemoveModal:(SV_MODAL&&!SV_MODAL.hidden)?SV:(HAMB&&!HAMB.hidden)?HAMB:(P.on)?PB:document,
      a=document.activeElement;

  // En la vista de búsqueda con teclado a la IZQUIERDA y resultados a la DERECHA
  if(cur&&cur.v==='search'&&(!SV_MODAL||SV_MODAL.hidden)&&!P.on&&(!HAMB||HAMB.hidden)){
    var kbGrid=document.querySelector('.tv-keyboard-grid');
    var resCol=document.querySelector('.search-results-col');
    if(kbGrid&&resCol){
      var resEls=[].filter.call(resCol.querySelectorAll('.f'),function(e){
        return e.offsetParent!==null&&!e.hidden&&!e.disabled&&!e.closest('[hidden]');
      });
      var isInResults=resCol.contains(a);
      var isInKeyboard=kbGrid.contains(a);

      if(isInResults){
        if(d==='l'||d==='u'){
          var targetKey=(V._searchLastKey&&V._searchLastKey())||kbGrid.querySelector('.tv-key');
          if(targetKey){focus(targetKey);return}
        }
        if(resEls.length){
          var idx=resEls.indexOf(a);
          if(idx===-1){
            focus(resEls[0]);
            return;
          }
          var next=(d==='r'||d==='d')?resEls[Math.min(idx+1,resEls.length-1)]:
                   (d==='l'||d==='u')?resEls[Math.max(idx-1,0)]:null;
          if(next){focus(next);return}
        }
      }

      if(isInKeyboard&&d==='r'){
        var col=parseInt(a.dataset.col,10);
        var isRightEdge=(col===5||(a.classList.contains('key-span-2')&&col>=4));
        if(isRightEdge){
          var firstRes=resEls[0]||resCol.querySelector('.f');
          if(firstRes){focus(firstRes);return}
        }
      }

      if(isInKeyboard&&d==='d'){
        var nextRes=resEls[0]||resCol.querySelector('.f');
        if(nextRes){focus(nextRes);return}
      }
    }
  }

  var els=[].filter.call(root.querySelectorAll('.f'),function(e){
    return e.offsetParent!==null&&!e.hidden&&!e.closest('[hidden]')&&e!==a;
  });
  if(!a||!a.classList.contains('f')||!root.contains(a)){focus(els[0]);return}
  var r=a.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,best=null,bs=1e9;
  els.forEach(function(e){
    var q=e.getBoundingClientRect(),x=q.left+q.width/2-cx,y=q.top+q.height/2-cy,p,s,h=d==='l'||d==='r';
    if(d==='l'){if(x>-2)return;p=-x}
    else if(d==='r'){if(x<2)return;p=x}
    else if(d==='u'){if(y>-2)return;p=-y}
    else{if(y<2)return;p=y}
    s=h?Math.abs(y):Math.abs(x);
    var sc=p+s*(h?3:1.5);
    if(sc<bs){bs=sc;best=e}
  });
  if(best)focus(best);
}

function isBack(k){return k===8||k===27||k===10009||k===461||k===4}

document.addEventListener('keydown',function(e){
  var k=e.keyCode;

  if(C.maintenanceMode){e.preventDefault();return}

  // Si el modal central de carga está activo, bloquear interacción de fondo
  if(LD_MODAL&&!LD_MODAL.hidden){
    e.preventDefault();
    return;
  }

  if(favRemoveModal&&!favRemoveModal.hidden){
    if(isBack(k)){closeFavoriteRemoveModal();e.preventDefault();return}
    if(KEYS[k]){move(KEYS[k]);e.preventDefault();return}
    if(k===13&&document.activeElement&&document.activeElement.click){
      document.activeElement.click();
      e.preventDefault();
    }
    return;
  }

  if(RESUME_PROMPT&&!RESUME_PROMPT.hidden){
    if(isBack(k)){if(RESUME_PROMPT_CANCEL)RESUME_PROMPT_CANCEL.click();else closeP();e.preventDefault();return}
    if(KEYS[k]){move(KEYS[k]);e.preventDefault();return}
    if((k===13||k===32)&&document.activeElement&&document.activeElement.click){
      document.activeElement.click();
      e.preventDefault();
    }
    return;
  }

  if(SV_MODAL&&!SV_MODAL.hidden){
    if(isBack(k)){closeSvModal();e.preventDefault();return}
    if(KEYS[k]){move(KEYS[k]);e.preventDefault();return}
    if(k===13&&document.activeElement&&document.activeElement.click){
      document.activeElement.click();
      e.preventDefault();
      return;
    }
    return;
  }

  if(e.target&&e.target.tagName==='INPUT'){
    if(k===13&&V._run){V._run();e.preventDefault()}
    else if(k===27)e.target.blur();
    return;
  }

  if(HAMB&&!HAMB.hidden){
    if(isBack(k)){closeHamb();e.preventDefault();return}
    if(KEYS[k]){move(KEYS[k]);e.preventDefault();return}
    if(k===13&&document.activeElement&&document.activeElement.click){
      document.activeElement.click();
      e.preventDefault();
      return;
    }
  }

  if(P.on){
    if(isBack(k)){
      closeP();
      e.preventDefault();
      return;
    }
    // Teclas multimedia de mandos a distancia
    if(k===415||k===19||k===179){
      togglePlayPause();
      e.preventDefault();
      return;
    }
    if(k===412){
      performSeek(-10);
      e.preventDefault();
      return;
    }
    if(k===417){
      performSeek(10);
      e.preventDefault();
      return;
    }
    if(k===10252||k===176){
      playNextEp();
      e.preventDefault();
      return;
    }
    if(k===10253||k===177){
      playPrevEp();
      e.preventDefault();
      return;
    }

    var pbVisible=!PB.classList.contains('h');
    var actInPb=document.activeElement&&PB.contains(document.activeElement);

    if(k===37||k===39){
      if(!pbVisible&&VD&&!VD.hidden){
        performSeek(k===37?-10:10);
      }else if(pbVisible&&actInPb){
        move(KEYS[k]);
        showB();
      }else if(pbVisible&&PB_PLAY_BTN){
        focus(PB_PLAY_BTN);
        showB();
      }else{
        showB(true);
      }
      e.preventDefault();
      return;
    }

    if(!pbVisible){
      // Controles ocultos: acción directa en reproducción
      if(k===13||k===32){
        togglePlayPause();
        showB(true);
      }else if(k===37){
        performSeek(-10);
      }else if(k===39){
        performSeek(10);
      }else if(k===38){
        openPlayerMenu();
      }else if(k===40){
        showB(true);
      }else return;
      e.preventDefault();
      return;
    }

    // Controles visibles: navegación por DPAD entre botones del reproductor
    showB();

    if(k===13||k===32){
      if(actInPb&&document.activeElement.tagName==='BUTTON'){
        document.activeElement.click();
      }else{
        togglePlayPause();
        if(PB_PLAY_BTN)focus(PB_PLAY_BTN);
      }
      e.preventDefault();
      return;
    }

    if(KEYS[k]){
      if(!actInPb){
        if(PB_PLAY_BTN)focus(PB_PLAY_BTN);
      }else{
        move(KEYS[k]);
      }
      e.preventDefault();
      return;
    }
    return;
  }

  // Teclado físico en la vista de búsqueda
  if(cur&&cur.v==='search'&&V._searchKey){
    if(k===13&&document.activeElement&&document.activeElement.tagName==='BUTTON'){
      document.activeElement.click();
      e.preventDefault();
      return;
    }
    if(k===13&&document.activeElement&&document.activeElement.tagName!=='BUTTON'){
      if(V._searchRun){V._searchRun();e.preventDefault();return}
    }
    if(k===8){
      var currQ=V._searchQuery?V._searchQuery():'';
      if(currQ.length>0){
        V._searchKey('⌫');
        e.preventDefault();
        return;
      }
    }
    if(e.key&&e.key.length===1&&!e.ctrlKey&&!e.metaKey&&/[a-z0-9 ]/i.test(e.key)){
      V._searchKey(e.key===' '?'␣':e.key.toUpperCase());
      e.preventDefault();
      return;
    }
  }

  if(KEYS[k]){move(KEYS[k]);e.preventDefault()}
  else if(isBack(k)){back();e.preventDefault()}
});

/* ── Catálogo de Íconos SVG ── */
var SVG={
  'arrow-left':'<svg viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>',
  'arrow-right':'<svg viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg>',
  back:'<svg viewBox="0 0 24 24"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>',
  home:'<svg viewBox="0 0 24 24"><path d="M3 10.5L12 3l9 7.5V20a1.5 1.5 0 0 1-1.5 1.5H15v-6h-6v6H4.5A1.5 1.5 0 0 1 3 20v-9.5z"/></svg>',
  film:'<svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M8 4v5M16 4v5"/></svg>',
  tv:'<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="12" rx="2"/><path d="M8 21h8M12 17v4"/></svg>',
  sports:'<svg viewBox="0 0 24 24"><path d="M6 9H4a2 2 0 0 1-2-2V5h4m12 4h2a2 2 0 0 0 2-2V5h-4M6 4h12v6a6 6 0 0 1-12 0V4zm6 12v4m-4 0h8"/></svg>',
  live:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="2.5"/><path d="M6.3 6.3a8 8 0 0 0 0 11.4M17.7 6.3a8 8 0 0 1 0 11.4M3.5 3.5a12 12 0 0 0 0 17M20.5 3.5a12 12 0 0 1 0 17"/></svg>',
  cal:'<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/><circle cx="12" cy="15" r="1.5"/></svg>',
  find:'<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7.5"/><path d="M21 21l-4.5-4.5"/></svg>',
  play:'<svg viewBox="0 0 24 24"><polygon points="6 3 20 12 6 21 6 3" fill="currentColor" stroke="none"/></svg>',
  pause:'<svg viewBox="0 0 24 24"><rect x="6" y="4" width="4" height="16" rx="1" fill="currentColor"/><rect x="14" y="4" width="4" height="16" rx="1" fill="currentColor"/></svg>',
  layers:'<svg viewBox="0 0 24 24"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',
  trash:'<svg viewBox="0 0 24 24"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>',
  'skip-back':'<svg viewBox="0 0 24 24"><polygon points="19 20 9 12 19 4 19 20" fill="currentColor"/><line x1="5" y1="19" x2="5" y2="5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  'skip-forward':'<svg viewBox="0 0 24 24"><polygon points="5 4 15 12 5 20 5 4" fill="currentColor"/><line x1="19" y1="5" x2="19" y2="19" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  'rw-10':'<svg viewBox="0 0 24 24"><path d="M12 5V1L7 6l5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6H4c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z" fill="currentColor"/></svg>',
  'ff-10':'<svg viewBox="0 0 24 24"><path d="M12 5V1l5 5-5 5V7c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6h2c0 4.42-3.58 8-8 8s-8-3.58-8-8 3.58-8 8-8z" fill="currentColor"/></svg>',
  menu:'<svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></svg>',
  globe:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3.6 9h16.8M3.6 15h16.8M12 3a14 14 0 0 0 0 18M12 3a14 14 0 0 1 0 18"/></svg>',
  fire:'<svg viewBox="0 0 24 24"><path d="M12 2c.5 3.5 3 5.5 3 8a6 6 0 1 1-12 0c0-4 3.5-6.5 4.5-9 2 2.5 3 3 4.5 1z"/></svg>',
  compass:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88"/></svg>',
  sparkles:'<svg viewBox="0 0 24 24"><path d="m12 3 2 5 5 2-5 2-2 5-2-5-5-2 5-2 2-5zm7 13 1 2.5 2.5 1-2.5 1-1 2.5-1-2.5-2.5-1 2.5-1 1-2.5z"/></svg>',
  smile:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M8 14s1.5 2 4 2 4-2 4-2M9 9h.01M15 9h.01"/></svg>',
  shield:'<svg viewBox="0 0 24 24"><path d="M12 3s8 3 8 9c0 5-5 8.5-8 9.5-3-1-8-4.5-8-9.5 0-6 8-9 8-9z"/></svg>',
  camera:'<svg viewBox="0 0 24 24"><path d="m15 10 5-3v10l-5-3v-4z"/><rect x="3" y="6" width="12" height="12" rx="2"/></svg>',
  theater:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M8 15s1.5-2 4-2 4 2 4 2M9 9h.01M15 9h.01"/></svg>',
  users:'<svg viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
  wand:'<svg viewBox="0 0 24 24"><path d="m15 4 5 2-2 5M18 6l-9 9m-4 4 3-3-2-2-3 3a1.4 1.4 0 0 0 2 2z"/></svg>',
  book:'<svg viewBox="0 0 24 24"><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1-2.5-2.5z"/><path d="M6 6h10M6 10h10M6 14h6"/></svg>',
  ghost:'<svg viewBox="0 0 24 24"><path d="M9 10h.01M15 10h.01M12 2a8 8 0 0 0-8 8v11l3-2 3 2 2-2 2 2 3-2 3 2V10a8 8 0 0 0-8-8z"/></svg>',
  music:'<svg viewBox="0 0 24 24"><circle cx="7" cy="17" r="3"/><circle cx="17" cy="15" r="3"/><path d="M10 17V6l10-2v11"/></svg>',
  heart:'<svg viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>',
  'heart-fill':'<svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" fill="currentColor" stroke="none"/></svg>',
  rocket:'<svg viewBox="0 0 24 24"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-4.05 11a22.4 22.4 0 0 1-3.95 2z"/></svg>',
  zap:'<svg viewBox="0 0 24 24"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
  swords:'<svg viewBox="0 0 24 24"><path d="m14.5 17.5 3 3 4-4-3-3M6.5 9.5 2.5 5.5l4-4 4 4M14 6l4 4-9 9-4-4 9-9zM3 21l3-3M21 3l-3 3"/></svg>',
  star:'<svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
  ball:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7l3.5 2.5-1.5 4.5h-4L8.5 9.5 12 7zm0-5v5m7.5 1.5l-4 1m-7 0l-4-1m2 8l-3 3m13-3l3 3m-9 0v5"/></svg>',
  grid:'<svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/></svg>',
  'arrow-up':'<svg viewBox="0 0 24 24"><path d="M12 19V5M5 12l7-7 7 7"/></svg>',
  'arrow-down':'<svg viewBox="0 0 24 24"><path d="M12 5v14M5 12l7 7 7-7"/></svg>',
  'sort-asc':'<svg viewBox="0 0 24 24"><path d="M3 6h18M3 12h12M3 18h6"/><path d="M18 9l3 3-3 3"/></svg>',
  'sort-desc':'<svg viewBox="0 0 24 24"><path d="M3 6h18M3 12h12M3 18h6"/><path d="M18 15l3-3-3-3"/></svg>'
};

function ic(n){
  var x=E('span','ic');
  if(SVG[n])x.innerHTML=SVG[n];
  else x.innerHTML=SVG.grid;
  return x;
}

var GMAP=[
  ['accion','fire'],
  ['aventura','compass'],
  ['animacion','sparkles'],
  ['comedia','smile'],
  ['crimen','shield'],
  ['documental','camera'],
  ['drama','theater'],
  ['familia','users'],
  ['fantasia','wand'],
  ['historia','book'],
  ['terror','ghost'],
  ['horror','ghost'],
  ['musica','music'],
  ['misterio','find'],
  ['romance','heart'],
  ['ciencia','rocket'],
  ['ficcion','rocket'],
  ['suspenso','zap'],
  ['thriller','zap'],
  ['guerra','swords'],
  ['western','star'],
  ['oeste','star'],
  ['reality','tv'],
  ['deporte','sports']
];

function getGenreIcon(name){
  var m=nrm(name);
  for(var i=0;i<GMAP.length;i++){
    if(m.indexOf(GMAP[i][0])>-1)return GMAP[i][1];
  }
  return'grid';
}

function getSportIcon(name){
  var m=nrm(name);
  if(m.indexOf('fut')>-1||m.indexOf('soc')>-1)return'ball';
  if(m.indexOf('bal')>-1||m.indexOf('bas')>-1)return'sports';
  if(m.indexOf('ten')>-1)return'sports';
  if(m.indexOf('mot')>-1||m.indexOf('f1')>-1||m.indexOf('auto')>-1)return'zap';
  if(m.indexOf('box')>-1||m.indexOf('mma')>-1||m.indexOf('luch')>-1)return'fire';
  return'sports';
}

function tip(b){
  var r=b.getBoundingClientRect();
  TP.textContent=b.dataset.t;
  TP.style.left=(r.right+10)+'px';
  TP.style.top=(r.top+r.height/2)+'px';
  TP.hidden=false;
}
function tip0(){TP.hidden=true}

function navTo(v,a){
  stack=[];
  cur=null;
  go(v,a);
}

/* ── Constructor de elementos de menú ── */
function mk(c,k,label,icon,fn,p){
  var b=E('button','f '+c);
  b.dataset.k=k;
  if(p)b.dataset.p=p;
  if(icon)b.appendChild(ic(icon));
  b.appendChild(E('span',c==='si'?'si-txt':'nb-txt',label));
  b.onclick=fn;
  if(c==='si'){
    b.dataset.t=label;
    b.setAttribute('aria-label',label);
    b.title=label;
    b.addEventListener('focus',function(){tip(b)});
    b.addEventListener('mouseenter',function(){tip(b)});
    b.addEventListener('blur',tip0);
    b.addEventListener('mouseleave',tip0);
    b.addEventListener('click',tip0);
  }
  return b;
}

/* ── Barra Lateral: SOLO EL LOGO (Sin textos) y Opciones de Menú ── */
function buildSide(){
  SD.innerHTML='';
  var br=E('div','sbrand'),
      bd=E('b',null,(C.name||'G').charAt(0).toUpperCase()),
      lg=new Image();

  lg.alt='';
  lg.hidden=true;
  lg.onload=function(){bd.hidden=true;lg.hidden=false};
  lg.onerror=function(){lg.remove()};
  lg.src=C.logo||(C.root+'/assets/logo.png');

  br.appendChild(bd);
  br.appendChild(lg);
  SD.appendChild(br);

  /* Opciones de menú */
  SD.appendChild(mk('si','home','Inicio','home',function(){navTo('home')}));
  SD.appendChild(mk('si','browse:pelicula','Películas','film',function(){navTo('browse','pelicula')}));
  SD.appendChild(mk('si','browse:serie','Series','tv',function(){navTo('browse','serie')}));
  SD.appendChild(mk('si','favorites','Mi Lista','heart',function(){navTo('favorites')}));

  /* Menú directo para Géneros (sin botón para cambiar dentro) */
  var btnG=mk('si','hamb:genres','Géneros','menu',function(){openHamb('genres')});
  btnG.id='btnHambG';
  SD.appendChild(btnG);

  /* Menú directo para Eventos Deportivos (sin botón para cambiar dentro) */
  if(C.sports){
    var btnE=mk('si','hamb:sports','Eventos en vivo','live',function(){openHamb('sports')});
    btnE.id='btnHambE';
    SD.appendChild(btnE);
  }

  hl();
}

/* ── Barra Superior (con Botón Buscar destacado y moderno) ── */
function buildTop(){
  N.innerHTML='';
  var nt=E('div','nt'),
      tabs=[
        ['Inicio','home','home',function(){navTo('home')}],
        ['Películas','browse:pelicula','film',function(){navTo('browse','pelicula')}],
        ['Series','browse:serie','tv',function(){navTo('browse','serie')}],
        ['Mi Lista','favorites','heart',function(){navTo('favorites')}]
      ];
  if(C.sports){
    tabs.push(['En vivo','sports:','live',function(){navTo('sports')},'sports:']);
  }
  tabs.forEach(function(t){
    nt.appendChild(mk('nb',t[1],t[0],t[2],t[3],t[4]));
  });
  N.appendChild(nt);

  var nr=E('div','nr'),
      sb=E('button','f head-search'),
      ck=E('span');

  sb.dataset.k='search';
  sb.setAttribute('aria-label','Buscar');
  sb.appendChild(ic('find'));
  sb.appendChild(E('span',null,'Buscar'));
  sb.onclick=function(){navTo('search')};

  ck.id='clk';
  function tick(){
    var d=new Date();
    ck.textContent=('0'+d.getHours()).slice(-2)+':'+('0'+d.getMinutes()).slice(-2);
  }
  tick();
  setInterval(tick,15000);

  nr.appendChild(sb);
  nr.appendChild(ck);
  N.appendChild(nr);
}

buildSide();
buildTop();
// Cargar vista según URL actual (deep linking)
(function(){
  var init=parseInitURL();
  cur=init;
  pushURL(init.v,init.a,true);
  render();
})();

})();
