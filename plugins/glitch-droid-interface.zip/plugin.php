<?php
/** Glitch Droid Interface · ThesthipOficial — Interfaz móvil servida en /api/v1/ext.php?plugin=glitch-droid-interface&r=mobile */

/* ────────────────────────────────────────────────────────────────────────────
 * GoalStream (eventos deportivos) — el plugin consulta la API de tu instalación
 * de GoalStream desde el servidor (sin CORS, sin contenido mixto y sin exponer
 * la API key) y la entrega ya normalizada a la interfaz.
 * ──────────────────────────────────────────────────────────────────────────── */

/** URL base de GoalStream sin "/api" ni barra final ('' si no está configurada). */
$gtvGsBase = function () use ($plugin): string {
    $u = trim((string)$plugin->option('gs_url', ''));
    if (!preg_match('#^https?://[^\s"<>]+$#i', $u)) {
        return '';
    }
    $u = rtrim($u, '/');
    $u = preg_replace('#/(index\.(html|php)|api(/index\.php)?)$#i', '', $u);
    return rtrim((string)$u, '/');
};

/** Descarga GET /api/index.php de GoalStream (JSON) con caché corta en la carpeta de datos del plugin. */
$gtvGsGet = function (array $params, int $ttl = 25) use ($plugin, $gtvGsBase): array {
    $base = $gtvGsBase();
    if ($base === '') {
        throw new InvalidArgumentException('GoalStream no está configurado (Ajustes Glitch Droid).');
    }
    $url   = $base . '/api/index.php' . ($params ? '?' . http_build_query($params) : '');
    $dir   = $plugin->dataDir();
    $cache = $dir . '/gs_' . md5($url) . '.json';

    if ($ttl > 0 && is_file($cache) && (time() - (int)@filemtime($cache)) < $ttl) {
        $c = json_decode((string)@file_get_contents($cache), true);
        if (is_array($c) && !empty($c['ok'])) {
            return $c;
        }
    }

    $body = '';
    $code = 0;
    $err  = '';
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 3,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_ENCODING       => '',
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_USERAGENT      => 'GlitchDroid/1.2 (GoalStream client)',
            CURLOPT_HTTPHEADER     => ['Accept: application/json'],
        ]);
        $r    = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_errno($ch) ? curl_error($ch) : '';
        curl_close($ch);
        $body = $r === false ? '' : (string)$r;
    } else {
        $ctx  = stream_context_create(['http' => ['timeout' => 15, 'ignore_errors' => true, 'header' => "Accept: application/json\r\nUser-Agent: GlitchDroid/1.2\r\n"], 'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]]);
        $r    = @file_get_contents($url, false, $ctx);
        $body = $r === false ? '' : (string)$r;
        $code = $body !== '' ? 200 : 0;
        if (isset($http_response_header[0]) && preg_match('#\s(\d{3})\s#', $http_response_header[0], $m)) {
            $code = (int)$m[1];
        }
    }

    $j = $body !== '' ? json_decode($body, true) : null;
    if (is_array($j) && !empty($j['ok']) && isset($j['eventos']) && is_array($j['eventos'])) {
        @file_put_contents($cache, $body, LOCK_EX);
        foreach ((array)glob($dir . '/gs_*.json') as $old) {          // limpia cachés viejas (> 1 h)
            if ((time() - (int)@filemtime($old)) > 3600) {
                @unlink($old);
            }
        }
        return $j;
    }

    // Si GoalStream falla, se sirve la última copia buena (si tiene menos de 10 minutos).
    if (is_file($cache) && (time() - (int)@filemtime($cache)) < 600) {
        $c = json_decode((string)@file_get_contents($cache), true);
        if (is_array($c) && !empty($c['ok'])) {
            $c['stale'] = true;
            return $c;
        }
    }
    if ($code === 401) {
        throw new InvalidArgumentException('GoalStream rechazó la conexión pública. Verifica que la URL permita acceso sin autenticación.');
    }
    if (is_array($j) && !empty($j['error'])) {
        throw new InvalidArgumentException('GoalStream: ' . mb_substr((string)$j['error'], 0, 120));
    }
    throw new InvalidArgumentException('No se pudo conectar con GoalStream' . ($err !== '' ? ' (' . mb_substr($err, 0, 80) . ')' : ($code ? ' (HTTP ' . $code . ')' : '')) . '.');
};

/** Solo http(s); cualquier otro esquema (javascript:, data:…) se descarta. */
$gtvUrl = static function ($u): string {
    $u = trim((string)$u);
    return preg_match('#^https?://[^\s"<>]+$#i', $u) ? $u : '';
};

/**
 * GET /api/v1/ext.php?plugin=glitch-droid-interface&r=sports
 *   estado=en_vivo|proximo|finalizado · deporte=football · q=texto · limite=N · zona=America/Lima
 *   slider=1  → primeros eventos para el slider (sin finalizados, en vivo primero, máx. «Eventos en el slider»)
 */
$plugin->route('sports', function (array $q) use ($plugin, $gtvGsGet, $gtvUrl) {
    $p = [];
    if (in_array($q['estado'] ?? '', ['en_vivo', 'proximo', 'finalizado'], true)) {
        $p['estado'] = $q['estado'];
    }
    if (!empty($q['deporte']) && preg_match('/^[A-Za-z0-9_-]{1,40}$/', $q['deporte'])) {
        $p['deporte'] = $q['deporte'];
    }
    if (!empty($q['q'])) {
        $p['q'] = mb_substr($q['q'], 0, 60);
    }
    if (!empty($q['zona']) && in_array($q['zona'], DateTimeZone::listIdentifiers(), true)) {
        $p['zona'] = $q['zona'];
    }
    $slider = !empty($q['slider']);
    if (!$slider) {
        $p['limite'] = max(1, min(150, (int)($q['limite'] ?? 100)));
    }

    $d    = $gtvGsGet($p, !empty($q['_']) ? 0 : 25);
    $live = [];
    $rest = [];
    foreach ((array)($d['eventos'] ?? []) as $e) {
        if (!is_array($e) || ($slider && ($e['estado'] ?? '') === 'finalizado')) {
            continue;
        }
        $srv = [];
        foreach ((array)($e['servidores'] ?? []) as $i => $s) {
            if (!is_array($s)) {
                continue;
            }
            $hls = $gtvUrl($s['url_proxy'] ?? '');
            $emb = $gtvUrl($s['url_reproductor'] ?? '');
            $raw = $gtvUrl($s['url'] ?? '');
            if ($hls === '' && $emb === '' && $raw === '') {
                continue;
            }
            $srv[] = [
                'name'    => mb_substr(trim((string)($s['nombre'] ?? '')) ?: 'Servidor ' . ($i + 1), 0, 60),
                'hls'     => $hls,
                'embed'   => $emb,
                'url'     => $raw,
                'quality' => mb_substr((string)($s['calidad'] ?? ''), 0, 12),
                'langs'   => array_values(array_filter(array_map(fn($x) => is_scalar($x) ? mb_substr((string)$x, 0, 20) : '', (array)($s['idiomas'] ?? [])))),
            ];
        }
        $item = [
            'id'        => (string)($e['id'] ?? ''),
            'sport_id'  => (string)($e['deporte_id'] ?? ''),
            'sport'     => (string)($e['deporte'] ?? ''),
            'icon'      => (string)($e['icono'] ?? ''),
            'league'    => (string)($e['liga'] ?? ''),
            'title'     => (string)($e['titulo'] ?? ''),
            'home'      => (string)($e['local'] ?? ''),
            'away'      => (string)($e['visitante'] ?? ''),
            'home_logo' => $gtvUrl($e['logo_local'] ?? ''),
            'away_logo' => $gtvUrl($e['logo_visit'] ?? ''),
            'date'      => (string)($e['fecha'] ?? ''),
            'time'      => (string)($e['hora'] ?? ''),
            'start'     => (string)($e['inicio_iso'] ?? ''),
            'status'    => (string)($e['estado'] ?? 'proximo'),
            'live'      => !empty($e['en_vivo']),
            'note'      => mb_substr((string)($e['nota'] ?? ''), 0, 200),
            'servers'   => $srv,
        ];
        if ($item['live']) {
            $live[] = $item;
        } else {
            $rest[] = $item;
        }
    }
    $events = array_merge($live, $rest);
    if ($slider) {
        $events = array_slice($events, 0, 6);
    }
    return ['events' => $events, 'total' => count($events), 'updated' => $d['actualizado'] ?? null, 'stale' => !empty($d['stale'])];
});

$plugin->route('mobile', function (array $q) use ($plugin, $gtvGsBase) {
    $dir  = __DIR__;
    $root = rtrim(str_replace('/api/v1', '', api_base_url()), '/');
    $asset = function (string $f) use ($plugin, $dir, $root) {
        return $root . '/api/plugins-front.php?p=' . $plugin->slug . '&amp;f=' . $f . '&amp;v=' . (int)@filemtime($dir . '/' . $f);
    };
    $name = (string)$plugin->option('name', 'Glitch Droid');
    $cfg = [
        'api' => api_base_url(),
        'root' => $root,
        'name' => $name,
        'theme' => [
            'a'  => (string)$plugin->option('accent', '#7c5cff'),
            'b'  => (string)$plugin->option('accent_secondary', '#19e3d6'),
            'bg' => (string)$plugin->option('theme_bg', '#090818'),
            's'  => (string)$plugin->option('theme_surface', '#12112a'),
            's2' => (string)$plugin->option('theme_surface_alt', '#1b1a3e'),
            't'  => (string)$plugin->option('theme_text', '#f3f4fc'),
            'm'  => (string)$plugin->option('theme_muted', '#9598bd'),
            'bd' => (string)$plugin->option('theme_border', '#26244f'),
        ],
        'maintenanceMode' => (bool)$plugin->option('maintenance_mode', false),
        'maintenance' => [
            'bg' => (string)$plugin->option('maintenance_bg', '#090818'),
            'text' => (string)$plugin->option('maintenance_text', '#f3f4fc'),
            'accent' => (string)$plugin->option('maintenance_accent', '#19e3d6'),
            'title' => (string)$plugin->option('maintenance_title', 'Modo mantenimiento'),
            'message' => (string)$plugin->option('maintenance_message', 'Estamos realizando tareas de mantenimiento. Vuelve pronto.'),
            'icon' => (string)$plugin->option('maintenance_icon', 'tools'),
            'image' => (string)$plugin->option('maintenance_image', ''),
        ],
        'includeEmbeds' => (bool)$plugin->option('include_embeds', false),
        'webVideoCaster' => (bool)$plugin->option('web_video_caster', false),
        'logo' => (string)$plugin->option('logo', ''),
        'sports' => $gtvGsBase() !== '',
    ];
    echo strtr((string)file_get_contents($dir . '/templates/mobile.html'), [
        '{{NAME}}' => htmlspecialchars($name, ENT_QUOTES, 'UTF-8'),
        '{{CSS}}' => $asset('assets/mobile.css'),
        '{{JS}}'  => $asset('assets/mobile.js'),
        '{{CFG}}' => json_encode($cfg, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP),
    ]);
    exit;
});
// El HTML lo imprime la ruta; ext.php enviaría JSON, así que fijamos cabeceras al arrancar la ruta.
$plugin->on('api.request', function () {
    if (($_GET['plugin'] ?? '') === 'glitch-droid-interface' && ($_GET['r'] ?? '') === 'mobile') {
        header('Content-Type: text/html; charset=utf-8');
        header('Cache-Control: no-cache');
    }
});

$plugin->adminPage('mobile', 'Ajustes Glitch Droid Mobile', function () use ($plugin, $gtvGsBase, $gtvGsGet) {
    $msg = '';
    $msgOk = false;
    $themeDefaults = [
        'accent' => ['Color principal', '#7c5cff'],
        'accent_secondary' => ['Color secundario', '#19e3d6'],
        'theme_bg' => ['Fondo', '#090818'],
        'theme_surface' => ['Panel', '#12112a'],
        'theme_surface_alt' => ['Panel secundario', '#1b1a3e'],
        'theme_text' => ['Texto', '#f3f4fc'],
        'theme_muted' => ['Texto secundario', '#9598bd'],
        'theme_border' => ['Bordes', '#26244f'],
    ];
    $maintenanceDefaults = [
        'maintenance_bg' => ['Fondo', '#090818'],
        'maintenance_text' => ['Texto', '#f3f4fc'],
        'maintenance_accent' => ['Color de acento', '#19e3d6'],
    ];
    $maintenanceIcons = [
        'tools' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14.7 6.3a5 5 0 0 0-6.4 6.4L3 18l3 3 5.3-5.3a5 5 0 0 0 6.4-6.4l-3 3-3-3 3-3Z"/><path d="m14 4 2-2 6 6-2 2"/></svg>',
        'gear' => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1 1.4 1.1-1.4 2.4-1.7-.7a8 8 0 0 1-1.6.9L16 21h-2.8l-.3-1.8a8 8 0 0 1-1.8 0L10.8 21H8l-.2-2.2a8 8 0 0 1-1.6-.9l-1.7.7-1.4-2.4 1.4-1.1a8 8 0 0 1-.2-1.9l-1.6-.9 1-2.6 1.8.2a8 8 0 0 1 1.2-1.3L6.2 5l2.5-1.3 1.1 1.4a8 8 0 0 1 1.9-.2l.8-1.7 2.7.7-.1 1.9a8 8 0 0 1 1.5 1l1.7-.8 1.6 2.3-1.3 1.3a8 8 0 0 1 .3 1.8l1.7.8-.7 2.7-1.9-.1a8 8 0 0 1-1.1 1.2Z"/></svg>',
        'refresh' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 7v5h-5M4 17v-5h5"/><path d="M6.1 9a7 7 0 0 1 11.6-2L20 12M4 12l2.3 5a7 7 0 0 0 11.6-2"/></svg>',
        'shield' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z"/><path d="m9 12 2 2 4-4"/></svg>',
        'sparkles' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z"/><path d="m19 14 .9 2.1L22 17l-2.1.9L19 20l-.9-2.1L16 17l2.1-.9L19 14ZM5 3l.7 1.7L7.5 5.5l-1.8.7L5 8l-.7-1.8-1.8-.7 1.8-.8L5 3Z"/></svg>',
        'clock' => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>',
    ];
    $settingsTabs = ['general' => 'General', 'appearance' => 'Apariencia', 'playback' => 'Reproducción', 'maintenance' => 'Mantenimiento', 'goalstream' => 'GoalStream'];
    $activeTab = (string)($_POST['settings_tab'] ?? 'general');
    if (!isset($settingsTabs[$activeTab])) $activeTab = 'general';
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $scriptPath = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? '/admin/index.php'));
    $sitePath = rtrim(str_replace('\\', '/', dirname(dirname($scriptPath))), '/');
    $siteRoot = ($https ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . $sitePath;
    $storeImageUpload = function ($upload, string $prefix) use ($plugin, $siteRoot): array {
        if (!is_array($upload) || ($upload['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return [null, ''];
        if (($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || (int)($upload['size'] ?? 0) > 8 * 1024 * 1024) {
            return [null, 'La imagen no se pudo subir (máximo 8 MB).'];
        }
        $tmpFile = (string)($upload['tmp_name'] ?? '');
        $imageInfo = $tmpFile !== '' ? @getimagesize($tmpFile) : false;
        $mime = is_array($imageInfo) ? strtolower((string)($imageInfo['mime'] ?? '')) : '';
        $imageTypes = [
            'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif',
            'image/webp' => 'webp', 'image/avif' => 'avif', 'image/bmp' => 'bmp',
            'image/x-ms-bmp' => 'bmp', 'image/tiff' => 'tif',
            'image/vnd.microsoft.icon' => 'ico', 'image/x-icon' => 'ico',
        ];
        if (!is_array($imageInfo) || !isset($imageTypes[$mime])) {
            return [null, 'Formato no válido. Usa JPG, PNG, GIF, WebP u otra imagen raster compatible.'];
        }
        $mediaDir = $plugin->dataDir() . '/maintenance-media';
        if (!is_dir($mediaDir) && !@mkdir($mediaDir, 0750, true) && !is_dir($mediaDir)) {
            return [null, 'No se pudo crear el directorio persistente de imágenes.'];
        }
        try {
            $filename = $prefix . '_' . bin2hex(random_bytes(12)) . '.' . $imageTypes[$mime];
        } catch (Throwable $ex) {
            return [null, 'No se pudo crear un nombre seguro para la imagen.'];
        }
        $destFile = $mediaDir . '/' . $filename;
        if (!is_uploaded_file($tmpFile) || !@move_uploaded_file($tmpFile, $destFile)) {
            return [null, 'No se pudo guardar la imagen subida.'];
        }
        @chmod($destFile, 0644);
        return [$siteRoot . '/api/plugins-front.php?media=glitch-droid-interface&f=' . rawurlencode($filename), ''];
    };
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        $tok = (string)($_POST[CSRF_TOKEN_NAME] ?? '');
        $st  = (string)($_SESSION[CSRF_TOKEN_NAME] ?? '');
        if ($st === '' || !hash_equals($st, $tok)) {
            $msg = 'Token de seguridad no válido. Recarga la página.';
        } else {
            $name   = mb_substr(trim(strip_tags((string)($_POST['name'] ?? ''))), 0, 40) ?: 'Glitch Droid';
            $resetTheme = isset($_POST['reset_theme']) && (string)$_POST['reset_theme'] === '1';
            $currentLogo = (string)$plugin->option('logo', '');
            $logoInput = trim((string)($_POST['logo'] ?? ''));
            $logo = (string)($_POST['remove_logo'] ?? '') === '1' ? '' : ($logoInput !== '' && preg_match('#^https?://[^\s"<>]{1,2048}$#i', $logoInput) ? $logoInput : $currentLogo);
            $uploadErrors = [];
            [$uploadedLogo, $logoUploadError] = $storeImageUpload($_FILES['logo_file'] ?? null, 'logo');
            if ($uploadedLogo !== null) $logo = $uploadedLogo;
            if ($logoUploadError !== '') $uploadErrors[] = $logoUploadError;
            $plugin->setOption('name', $name);
            foreach ($themeDefaults as $key => $field) {
                $raw = $resetTheme ? $field[1] : (string)($_POST[$key] ?? $plugin->option($key, $field[1]));
                $color = preg_match('/^#[0-9a-f]{6}$/i', $raw) ? strtolower($raw) : $field[1];
                $plugin->setOption($key, $color);
            }
            $resetMaintenance = isset($_POST['reset_maintenance']) && (string)$_POST['reset_maintenance'] === '1';
            foreach ($maintenanceDefaults as $key => $field) {
                $raw = $resetMaintenance ? $field[1] : (string)($_POST[$key] ?? $plugin->option($key, $field[1]));
                $color = preg_match('/^#[0-9a-f]{6}$/i', $raw) ? strtolower($raw) : $field[1];
                $plugin->setOption($key, $color);
            }
            $maintenanceTitle = mb_substr(trim(strip_tags((string)($_POST['maintenance_title'] ?? ''))), 0, 70);
            $maintenanceMessage = mb_substr(trim(strip_tags((string)($_POST['maintenance_message'] ?? ''))), 0, 240);
            $maintenanceIcon = (string)($_POST['maintenance_icon'] ?? 'tools');
            $maintenanceIconCustom = mb_substr(trim(strip_tags((string)($_POST['maintenance_icon_custom'] ?? ''))), 0, 8);
            if ($maintenanceIconCustom !== '') {
                $maintenanceIcon = $maintenanceIconCustom;
            } elseif (!isset($maintenanceIcons[$maintenanceIcon])) {
                $maintenanceIcon = 'tools';
            }
            $maintenanceImageInput = trim((string)($_POST['maintenance_image'] ?? ''));
            $maintenanceImage = (string)($_POST['remove_maintenance_image'] ?? '') === '1' ? '' : ($maintenanceImageInput !== '' && preg_match('#^https?://[^\s"<>]{1,2048}$#i', $maintenanceImageInput) ? $maintenanceImageInput : (string)$plugin->option('maintenance_image', ''));
            [$uploadedMaintenanceImage, $maintenanceUploadError] = $resetMaintenance ? [null, ''] : $storeImageUpload($_FILES['maintenance_image_file'] ?? null, 'maintenance');
            if ($uploadedMaintenanceImage !== null) $maintenanceImage = $uploadedMaintenanceImage;
            if ($maintenanceUploadError !== '') $uploadErrors[] = $maintenanceUploadError;
            $plugin->setOption('maintenance_title', $resetMaintenance || $maintenanceTitle === '' ? 'Modo mantenimiento' : $maintenanceTitle);
            $plugin->setOption('maintenance_message', $resetMaintenance || $maintenanceMessage === '' ? 'Estamos realizando tareas de mantenimiento. Vuelve pronto.' : $maintenanceMessage);
            $plugin->setOption('maintenance_icon', $resetMaintenance ? 'tools' : $maintenanceIcon);
            $plugin->setOption('maintenance_image', $resetMaintenance ? '' : $maintenanceImage);
            $plugin->setOption('include_embeds', isset($_POST['include_embeds']) && (string)$_POST['include_embeds'] === '1');
            $plugin->setOption('web_video_caster', isset($_POST['web_video_caster']) && (string)$_POST['web_video_caster'] === '1');
            $plugin->setOption('maintenance_mode', isset($_POST['maintenance_mode']) && (string)$_POST['maintenance_mode'] === '1');
            $plugin->setOption('logo', $logo);

            // GoalStream (eventos deportivos)
            $gs = trim((string)($_POST['gs_url'] ?? ''));
            $plugin->setOption('gs_url', preg_match('#^https?://[^\s"<>]+$#i', $gs) ? $gs : '');
            $uploadMessage = implode(' ', $uploadErrors);
            $msg = $uploadMessage !== '' ? $uploadMessage : ($resetMaintenance ? 'Diseño de mantenimiento restablecido.' : ($resetTheme ? 'Colores restablecidos; los demás ajustes se guardaron.' : 'Ajustes guardados.'));
            $msgOk = $uploadMessage === '';
        }
    }
    $url = $siteRoot . '/api/v1/ext.php?plugin=glitch-droid-interface&r=mobile';
    $e = fn($s) => htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
    $gsMsg = '';
    $gsOk  = false;
    if ($gtvGsBase() !== '') {
        try {
            $r     = $gtvGsGet([], 0);
            $gsOk  = true;
            $gsMsg = '✔ Conectado a GoalStream · ' . count((array)$r['eventos']) . ' eventos en la agenda';
        } catch (Throwable $ex) {
            $gsMsg = '✖ ' . $ex->getMessage();
        }
    }
    $in = 'width:100%;max-width:100%;box-sizing:border-box;background:var(--bg);color:var(--text);border:1px solid var(--border);border-radius:9px;padding:10px 12px;font:inherit;margin:6px 0 14px';
    $themeFields = '';
    foreach ($themeDefaults as $key => $field) {
        $themeFields .= '<label style="display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:12.5px">' . $e($field[0])
            . '<input name="' . $e($key) . '" type="color" value="' . $e($plugin->option($key, $field[1])) . '" style="width:44px;height:36px;padding:2px;border:1px solid var(--border);border-radius:7px;background:var(--bg)"></label>';
    }
    $maintenanceFields = '';
    foreach ($maintenanceDefaults as $key => $field) {
        $maintenanceFields .= '<label style="display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:12.5px">' . $e($field[0])
            . '<input name="' . $e($key) . '" type="color" value="' . $e($plugin->option($key, $field[1])) . '" style="width:44px;height:36px;padding:2px;border:1px solid var(--border);border-radius:7px;background:var(--bg)"></label>';
    }
    $maintenanceIconLabels = ['tools' => 'Herramientas', 'gear' => 'Engranaje', 'refresh' => 'Actualización', 'shield' => 'Escudo', 'sparkles' => 'Destellos', 'clock' => 'Reloj'];
    $savedMaintenanceIcon = (string)$plugin->option('maintenance_icon', 'tools');
    $selectedMaintenanceIcon = isset($maintenanceIcons[$savedMaintenanceIcon]) ? $savedMaintenanceIcon : '';
    $customMaintenanceIcon = $selectedMaintenanceIcon === '' ? $savedMaintenanceIcon : '';
    $maintenanceIconOptions = '';
    foreach ($maintenanceIcons as $key => $svg) {
        $selected = $key === $selectedMaintenanceIcon;
        $maintenanceIconOptions .= '<button type="button" class="gtv-maint-icon' . ($selected ? ' is-selected' : '') . '" data-maintenance-icon="' . $e($key) . '" aria-label="' . $e($maintenanceIconLabels[$key] ?? $key) . '" aria-pressed="' . ($selected ? 'true' : 'false') . '">' . $svg . '</button>';
    }
    $savedMaintenanceImage = (string)$plugin->option('maintenance_image', '');
    $savedLogo = (string)$plugin->option('logo', '');
    $savedMaintenanceBg = (string)$plugin->option('maintenance_bg', '#090818');
    $savedMaintenanceText = (string)$plugin->option('maintenance_text', '#f3f4fc');
    $savedMaintenanceAccent = (string)$plugin->option('maintenance_accent', '#19e3d6');
    $previewMark = $selectedMaintenanceIcon !== '' ? $maintenanceIcons[$selectedMaintenanceIcon] : $e($customMaintenanceIcon ?: '!');
    if ($savedMaintenanceImage !== '') {
        $previewMark = '<img src="' . $e($savedMaintenanceImage) . '" alt="">';
    }
    $tabButtons = '';
    foreach ($settingsTabs as $key => $label) {
        $selected = $key === $activeTab;
        $tabButtons .= '<button type="button" class="gtv-settings-tab" id="gtv-tab-' . $e($key) . '" role="tab" data-settings-tab="' . $e($key) . '" aria-controls="gtv-panel-' . $e($key) . '" aria-selected="' . ($selected ? 'true' : 'false') . '">' . $e($label) . '</button>';
    }
     echo '<style>'
         . '@keyframes gtvToastIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}'
         . '@keyframes gtvToastOut{to{opacity:0;transform:translateY(8px)}}'
         . '.gtv-settings-toast{position:fixed;right:22px;bottom:22px;z-index:2000;display:flex;align-items:center;gap:10px;width:max-content;max-width:min(92vw,520px);padding:12px 18px;border:1px solid rgba(74,222,128,.38);border-radius:12px;background:#15251d;color:#b9f6cc;box-shadow:0 12px 32px rgba(0,0,0,.36);font-size:13px;font-weight:700;animation:gtvToastIn .2s ease-out,gtvToastOut .25s ease-in 3.5s forwards;pointer-events:none}'
         . '.gtv-settings-toast--error{border-color:rgba(255,107,107,.4);background:#2b191d;color:#ffc2c2}'
         . '.gtv-settings-toast__icon{width:20px;height:20px;display:grid;place-items:center;flex:0 0 auto;border-radius:50%;background:rgba(74,222,128,.16);color:#4ade80}'
         . '.gtv-settings-toast--error .gtv-settings-toast__icon{background:rgba(255,107,107,.16);color:#ff6b6b}'
         . '.gtv-switch{position:relative;display:inline-flex;align-items:center;gap:11px;min-height:36px;color:var(--text);font-size:13px;font-weight:600;cursor:pointer}'
         . '.gtv-switch input{position:absolute;width:1px;height:1px;opacity:0}'
         . '.gtv-switch__track{width:42px;height:24px;display:inline-flex;align-items:center;flex:0 0 auto;padding:3px;border:1px solid var(--border);border-radius:999px;background:var(--bg-soft);transition:background .16s,border-color .16s,box-shadow .16s}'
         . '.gtv-switch__thumb{width:16px;height:16px;border-radius:50%;background:var(--text-muted);transition:transform .16s,background .16s}'
         . '.gtv-switch input:checked+.gtv-switch__track{background:rgba(74,222,128,.2);border-color:#4ade80}'
         . '.gtv-switch input:checked+.gtv-switch__track .gtv-switch__thumb{transform:translateX(17px);background:#4ade80}'
         . '.gtv-switch input:focus-visible+.gtv-switch__track{outline:2px solid var(--accent-2);outline-offset:3px}'
        . '.gtv-settings-page{max-width:1180px;width:100%;display:grid;gap:16px}'
        . '.gtv-settings-url,.gtv-settings-form{background:var(--bg-card);border:1px solid var(--border);border-radius:14px;padding:clamp(16px,2.4vw,26px);width:100%;box-sizing:border-box}'
        . '.gtv-settings-tabs{display:flex;gap:6px;overflow-x:auto;border-bottom:1px solid var(--border);margin:-4px 0 20px;padding:0 0 10px;scrollbar-width:thin}'
        . '.gtv-settings-tab{flex:0 0 auto;padding:9px 14px;border:1px solid transparent;border-radius:8px;background:transparent;color:var(--text-muted);font:inherit;font-size:13px;font-weight:700;cursor:pointer}'
        . '.gtv-settings-tab:hover{background:var(--bg-soft);color:var(--text)}'
        . '.gtv-settings-tab[aria-selected="true"]{background:rgba(25,227,214,.1);border-color:rgba(25,227,214,.28);color:var(--accent-2)}'
        . '.gtv-settings-panel[hidden]{display:none!important}'
        . '.gtv-settings-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:16px 22px;align-items:start}'
        . '.gtv-settings-panel h2{font-size:16px;margin:0 0 5px}'
        . '.gtv-settings-panel .gtv-help{color:var(--text-muted);font-size:12.5px;line-height:1.5;margin:0 0 16px}'
        . '.gtv-settings-actions{display:flex;justify-content:flex-end;gap:10px;border-top:1px solid var(--border);padding-top:16px;margin-top:22px}'
        . '.gtv-maintenance-layout{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(270px,.85fr);gap:24px;align-items:start}'
        . '.gtv-maintenance-editor{display:grid;gap:15px;min-width:0}'
        . '.gtv-maintenance-copy-fields{grid-template-columns:repeat(auto-fit,minmax(210px,1fr))}'
        . '.gtv-maintenance-group{min-width:0;border:1px solid var(--border);border-radius:11px;padding:14px}'
        . '.gtv-maintenance-group legend{padding:0 7px;color:var(--text);font-size:12.5px;font-weight:700}'
        . '.gtv-maint-icon-gallery{display:grid;grid-template-columns:repeat(6,minmax(42px,1fr));gap:8px;margin:5px 0 14px}'
        . '.gtv-maint-icon{aspect-ratio:1;display:grid;place-items:center;border:1px solid var(--border);border-radius:9px;background:var(--bg-soft);color:var(--text-muted);cursor:pointer;transition:background .15s,border-color .15s,color .15s,transform .15s}'
        . '.gtv-maint-icon svg{width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}'
        . '.gtv-maint-icon:hover{color:var(--text);border-color:var(--accent-2)}.gtv-maint-icon.is-selected{color:var(--accent-2);background:rgba(25,227,214,.1);border-color:var(--accent-2);box-shadow:0 0 0 2px rgba(25,227,214,.12)}'
        . '.gtv-maint-icon:focus-visible{outline:2px solid var(--accent-2);outline-offset:2px}'
        . '.gtv-maint-custom-icon{display:block;color:var(--text-muted);font-size:12.5px}'
        . '.gtv-maintenance-actions{display:flex;justify-content:flex-end}'
        . '.gtv-maintenance-preview-wrap{position:sticky;top:18px;min-width:0}'
        . '.gtv-maintenance-preview-heading{display:flex;justify-content:space-between;align-items:baseline;gap:8px;margin-bottom:9px;color:var(--text);font-size:13px;font-weight:700}'
        . '.gtv-maintenance-preview-heading span{color:var(--text-muted);font-size:11px;font-weight:400}'
        . '.gtv-maintenance-preview{min-height:300px;aspect-ratio:4/3;display:grid;place-items:center;overflow:hidden;padding:18px;border:1px solid var(--border);border-radius:12px;background:radial-gradient(ellipse at 50% 42%,var(--preview-surface,var(--s2)),var(--preview-bg,var(--bg)) 68%);text-align:center}'
        . '.gtv-maintenance-preview-content{width:100%;display:flex;flex-direction:column;align-items:center;gap:10px}'
        . '.gtv-maintenance-preview-mark{width:50px;height:50px;display:grid;place-items:center;overflow:hidden;border:1px solid var(--preview-accent,var(--accent-2));border-radius:50%;background:linear-gradient(135deg,var(--preview-accent,var(--accent-2)),var(--accent));color:#fff;font-size:21px;font-weight:800}'
        . '.gtv-maintenance-preview-mark svg,.gtv-maintenance-preview-mark img{display:block;width:100%;height:100%;object-fit:cover}.gtv-maintenance-preview-mark svg{width:25px;height:25px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}'
        . '.gtv-maintenance-preview-brand{color:var(--preview-accent,var(--accent-2));font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}'
        . '.gtv-maintenance-preview-title{color:var(--preview-text,var(--text));font-size:18px;line-height:1.25}'
        . '.gtv-maintenance-preview-message{max-width:290px;color:var(--preview-text,var(--text-muted));font-size:12px;line-height:1.5;overflow-wrap:anywhere}'
        . '.gtv-upload-box{display:grid;grid-template-columns:92px minmax(0,1fr);align-items:center;gap:14px;padding:12px;border:1px dashed var(--border);border-radius:12px;background:var(--bg);transition:border-color .15s,background .15s}'
        . '.gtv-upload-box.is-dragging{border-color:var(--accent-2);background:rgba(25,227,214,.08)}'
        . '.gtv-upload-preview{width:92px;height:72px;display:grid;place-items:center;overflow:hidden;border:1px solid var(--border);border-radius:9px;background:var(--bg-soft);color:var(--text-muted);font-size:11px;text-align:center}'
        . '.gtv-upload-preview img{width:100%;height:100%;object-fit:contain}'
        . '.gtv-upload-controls{display:grid;gap:6px;min-width:0}.gtv-upload-controls strong{font-size:12.5px}.gtv-upload-controls small{color:var(--text-muted);font-size:11px;line-height:1.4}'
        . '.gtv-upload-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.gtv-upload-actions label{display:inline-flex!important;align-items:center;justify-content:center;min-height:34px;padding:7px 10px;border:1px solid var(--border);border-radius:8px;background:var(--bg-soft);color:var(--text);font-size:11.5px;font-weight:700;cursor:pointer}'
        . '.gtv-upload-actions input[type=file]{position:absolute;width:1px;height:1px;opacity:0;pointer-events:none}.gtv-upload-remove{padding:7px 10px;border:1px solid rgba(255,107,107,.3);border-radius:8px;background:rgba(255,107,107,.08);color:#ffb4b4;font:inherit;font-size:11.5px;font-weight:700;cursor:pointer}'
        . '.gtv-upload-status{min-height:1em;color:var(--text-muted);font-size:11px}.gtv-upload-status.is-error{color:#ff8e8e}'
        . '@media(max-width:520px){.gtv-upload-box{grid-template-columns:68px minmax(0,1fr);gap:10px;padding:9px}.gtv-upload-preview{width:68px;height:60px}}'
        . '@media(max-width:850px){.gtv-maintenance-layout{grid-template-columns:1fr}.gtv-maintenance-preview-wrap{position:static}.gtv-maintenance-preview{min-height:250px;aspect-ratio:16/10}}'
        . '.gtv-settings-footer{display:flex;align-items:center;gap:11px;padding:14px 18px;border:1px solid var(--border);border-radius:12px;background:var(--bg-soft);color:var(--text-muted)}'
        . '.gtv-settings-footer__mark{width:40px;height:40px;display:grid;place-items:center;flex:0 0 auto;overflow:hidden;border:1px solid var(--border);border-radius:11px;background:var(--bg)}'
        . '.gtv-settings-footer__mark img{display:block;width:100%;height:100%;object-fit:cover}'
        . '.gtv-settings-footer__brand{display:grid;gap:2px}.gtv-settings-footer__brand strong{color:var(--text);font-size:12.5px}.gtv-settings-footer__brand small,.gtv-settings-footer__credit{font-size:11.5px}'
        . '.gtv-settings-footer__credit{margin-left:auto;text-align:right}.gtv-settings-footer__credit a{color:var(--accent-2);font-weight:700;text-decoration:none}.gtv-settings-footer__credit a:hover,.gtv-settings-footer__credit a:focus-visible{text-decoration:underline}'
        . '@media(max-width:600px){.gtv-settings-toast{right:12px;bottom:12px}.gtv-settings-actions .btn{width:100%;justify-content:center}.gtv-settings-actions{flex-direction:column}.gtv-settings-footer{flex-wrap:wrap}.gtv-settings-footer__credit{width:100%;margin-left:45px;text-align:left}}'
         . '</style>';
     if ($msg) {
          echo '<div class="gtv-settings-toast' . ($msgOk ? '' : ' gtv-settings-toast--error') . '" role="status" aria-live="polite">'
              . '<span class="gtv-settings-toast__icon" aria-hidden="true">' . ($msgOk ? '✓' : '!') . '</span>' . $e($msg) . '</div>';
     }
     echo '<div class="gtv-settings-page">'
         . '<section class="gtv-settings-url"><label style="font-weight:700;font-size:13px">URL para tu app</label>'
         . '<p style="color:var(--text-muted);font-size:12.5px;margin-top:4px;word-break:break-word">Coloca esta URL en tu app móvil, navegador o WebView.</p>'
       . '<div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:10px 0 18px;width:100%;max-width:100%;box-sizing:border-box">'
       . '<input id="gtvUrl" readonly value="' . $e($url) . '" style="flex:1 1 220px;min-width:0;width:100%;max-width:100%;box-sizing:border-box;background:var(--bg);color:var(--accent-2);border:1px solid var(--border);border-radius:9px;padding:10px 12px;font:inherit;font-size:13px;word-break:break-all">'
       . '<div style="display:flex;gap:8px;flex:0 0 auto;flex-wrap:wrap">'
       . '<button type="button" class="btn" style="white-space:nowrap;display:inline-flex;align-items:center;gap:6px" onclick="var i=document.getElementById(\'gtvUrl\');i.select();(navigator.clipboard?navigator.clipboard.writeText(i.value):document.execCommand(\'copy\'));this.textContent=\'¡Copiada!\'">Copiar URL</button>'
       . '<a class="btn" style="white-space:nowrap;display:inline-flex;align-items:center;gap:6px" href="' . $e($url) . '" target="_blank" rel="noopener">Abrir</a>'
         . '</div></section>'
         . '<form class="gtv-settings-form" id="gtvSettingsForm" method="post" action="" enctype="multipart/form-data">' . AdminAuth::csrfField()
         . '<input type="hidden" name="settings_tab" id="gtvSettingsTabState" value="' . $e($activeTab) . '">'
         . '<div class="gtv-settings-tabs" role="tablist" aria-label="Secciones de ajustes">' . $tabButtons . '</div>'
         . '<section class="gtv-settings-panel" id="gtv-panel-general" role="tabpanel" aria-labelledby="gtv-tab-general" data-settings-panel="general"' . ($activeTab !== 'general' ? ' hidden' : '') . '>'
         . '<h2>General</h2><p class="gtv-help">Nombre e identidad de la aplicación.</p><div class="gtv-settings-grid">'
         . '<label>Nombre de la web<input name="name" maxlength="40" value="' . $e($plugin->option('name', 'Glitch Droid')) . '" style="' . $in . '"></label>'
         . '<label>URL del logo (opcional)<input id="gtvLogoUrl" name="logo" type="url" value="' . $e($savedLogo) . '" placeholder="https://..." style="' . $in . '"></label>'
         . '<input type="hidden" name="remove_logo" id="gtvRemoveLogo" value="">'
         . '<div class="gtv-upload-box" data-upload-box>'
         . '<span class="gtv-upload-preview" id="gtvLogoPreview" data-current-src="' . $e($savedLogo) . '">' . ($savedLogo !== '' ? '<img src="' . $e($savedLogo) . '" alt="Logo actual">' : 'Sin logo') . '</span>'
         . '<div class="gtv-upload-controls"><strong>Logo de la aplicación</strong><small>Arrastra una imagen aquí o selecciónala. JPG, PNG, GIF, WebP, AVIF, BMP, TIFF o ICO · máximo 8 MB.</small>'
         . '<div class="gtv-upload-actions"><label>Seleccionar imagen<input id="gtvLogoFile" name="logo_file" type="file" accept="image/*"></label><button class="gtv-upload-remove" type="button" id="gtvRemoveLogoBtn">Quitar logo</button></div><span class="gtv-upload-status" id="gtvLogoStatus" aria-live="polite"></span></div></div>'
         . '</div></section>'
         . '<section class="gtv-settings-panel" id="gtv-panel-appearance" role="tabpanel" aria-labelledby="gtv-tab-appearance" data-settings-panel="appearance"' . ($activeTab !== 'appearance' ? ' hidden' : '') . '>'
         . '<h2>Apariencia</h2><p class="gtv-help">Personaliza los colores principales del tema de Glitch Droid.</p>'
         . '<div class="gtv-settings-grid">' . $themeFields . '</div>'
         . '<div style="display:flex;justify-content:flex-end;margin-top:16px"><button class="btn btn--ghost" type="submit" name="reset_theme" value="1">Restablecer colores</button></div>'
         . '</section>'
         . '<section class="gtv-settings-panel" id="gtv-panel-playback" role="tabpanel" aria-labelledby="gtv-tab-playback" data-settings-panel="playback"' . ($activeTab !== 'playback' ? ' hidden' : '') . '>'
         . '<h2>Reproducción</h2><p class="gtv-help">Controla qué servidores se muestran y el estado de acceso de la app.</p>'
         . '<div style="display:grid;gap:12px">'
         . '<div><label class="gtv-switch"><input name="include_embeds" type="checkbox" value="1"' . ($plugin->option('include_embeds', false) ? ' checked' : '') . '><span class="gtv-switch__track" aria-hidden="true"><span class="gtv-switch__thumb"></span></span><span>Incluir enlaces embed junto a los directos</span></label><p class="gtv-help" style="margin:4px 0 0 53px">Desactivado por defecto: solo se muestran enlaces directos reproducibles.</p></div>'
         . '<div><label class="gtv-switch"><input name="web_video_caster" type="checkbox" value="1"' . ($plugin->option('web_video_caster', false) ? ' checked' : '') . '><span class="gtv-switch__track" aria-hidden="true"><span class="gtv-switch__thumb"></span></span><span>Permitir transmitir a Web Video Caster</span></label><p class="gtv-help" style="margin:4px 0 0 53px">Desactivado por defecto. Disponible en Android para servidores directos compatibles; los enlaces embed no se pueden transmitir desde este control.</p></div>'
         . '</div></section>'
         . '<section class="gtv-settings-panel" id="gtv-panel-maintenance" role="tabpanel" aria-labelledby="gtv-tab-maintenance" data-settings-panel="maintenance"' . ($activeTab !== 'maintenance' ? ' hidden' : '') . '>'
         . '<h2>Modo mantenimiento</h2><p class="gtv-help">Configura el bloqueo de la app y revisa cómo quedará la pantalla antes de guardar.</p>'
         . '<div class="gtv-maintenance-layout"><div class="gtv-maintenance-editor">'
         . '<label class="gtv-switch"><input name="maintenance_mode" type="checkbox" value="1"' . ($plugin->option('maintenance_mode', false) ? ' checked' : '') . '><span class="gtv-switch__track" aria-hidden="true"><span class="gtv-switch__thumb"></span></span><span>Activar modo mantenimiento</span></label>'
         . '<div class="gtv-settings-grid gtv-maintenance-copy-fields"><label>Título<input id="gtvMaintenanceTitle" name="maintenance_title" maxlength="70" value="' . $e($plugin->option('maintenance_title', 'Modo mantenimiento')) . '" style="' . $in . '"></label>'
         . '<label>Mensaje<textarea id="gtvMaintenanceMessage" name="maintenance_message" rows="3" maxlength="240" style="' . $in . ';resize:vertical">' . $e($plugin->option('maintenance_message', 'Estamos realizando tareas de mantenimiento. Vuelve pronto.')) . '</textarea></label></div>'
         . '<fieldset class="gtv-maintenance-group"><legend>Colores</legend><div class="gtv-settings-grid">' . $maintenanceFields . '</div></fieldset>'
         . '<fieldset class="gtv-maintenance-group"><legend>Icono</legend>'
         . '<input type="hidden" id="gtvMaintenanceIconValue" name="maintenance_icon" value="' . $e($selectedMaintenanceIcon !== '' ? $selectedMaintenanceIcon : $customMaintenanceIcon) . '">'
         . '<div class="gtv-maint-icon-gallery" role="group" aria-label="Galería de iconos">' . $maintenanceIconOptions . '</div>'
         . '<label class="gtv-maint-custom-icon">Símbolo o emoji personalizado<input id="gtvMaintenanceIconCustom" name="maintenance_icon_custom" maxlength="8" value="' . $e($customMaintenanceIcon) . '" placeholder="Ej. ! o emoji" style="' . $in . '"></label></fieldset>'
         . '<fieldset class="gtv-maintenance-group"><legend>Imagen</legend><div class="gtv-settings-grid">'
         . '<label>URL de imagen o GIF<input id="gtvMaintenanceImageUrl" name="maintenance_image" type="url" value="' . $e($savedMaintenanceImage) . '" placeholder="https://.../imagen.gif" style="' . $in . '"></label>'
         . '<input type="hidden" name="remove_maintenance_image" id="gtvRemoveMaintenanceImage" value="">'
         . '<div class="gtv-upload-box" id="gtvMaintenanceUploadBox" data-upload-box>'
         . '<span class="gtv-upload-preview" id="gtvMaintenanceImagePreview" data-current-src="' . $e($savedMaintenanceImage) . '">' . ($savedMaintenanceImage !== '' ? '<img src="' . $e($savedMaintenanceImage) . '" alt="Imagen de mantenimiento actual">' : 'Sin imagen') . '</span>'
         . '<div class="gtv-upload-controls"><strong>Imagen de mantenimiento</strong><small>Arrastra una imagen aquí o selecciónala. JPG, PNG, GIF, WebP, AVIF, BMP, TIFF o ICO · máximo 8 MB.</small>'
         . '<div class="gtv-upload-actions"><label>Seleccionar imagen<input id="gtvMaintenanceImageFile" name="maintenance_image_file" type="file" accept="image/*"></label><button class="gtv-upload-remove" type="button" id="gtvRemoveMaintenanceImageBtn">Quitar imagen</button></div><span class="gtv-upload-status" id="gtvMaintenanceImageStatus" aria-live="polite"></span></div></div>'
         . '<p class="gtv-help">Las imágenes subidas se conservan al actualizar.</p></fieldset>'
         . '<div class="gtv-maintenance-actions"><button class="btn btn--ghost" type="submit" name="reset_maintenance" value="1">Restablecer diseño</button></div>'
         . '</div><aside class="gtv-maintenance-preview-wrap"><div class="gtv-maintenance-preview-heading"><strong>Vista previa</strong><span>Se actualiza al editar</span></div>'
         . '<div class="gtv-maintenance-preview" id="gtvMaintenancePreview" style="--preview-surface:' . $e($plugin->option('theme_surface_alt', '#1b1a3e')) . ';--preview-bg:' . $e($savedMaintenanceBg) . ';--preview-text:' . $e($savedMaintenanceText) . ';--preview-accent:' . $e($savedMaintenanceAccent) . '">'
         . '<div class="gtv-maintenance-preview-content"><span class="gtv-maintenance-preview-mark" id="gtvMaintenancePreviewMark">' . $previewMark . '</span>'
         . '<span class="gtv-maintenance-preview-brand" id="gtvMaintenancePreviewBrand">' . $e($plugin->option('name', 'Glitch Droid')) . '</span>'
         . '<strong class="gtv-maintenance-preview-title" id="gtvMaintenancePreviewTitle">' . $e($plugin->option('maintenance_title', 'Modo mantenimiento')) . '</strong>'
         . '<span class="gtv-maintenance-preview-message" id="gtvMaintenancePreviewMessage">' . $e($plugin->option('maintenance_message', 'Estamos realizando tareas de mantenimiento. Vuelve pronto.')) . '</span>'
         . '</div></div></aside></div>'
         . '</section>'
         . '<section class="gtv-settings-panel" id="gtv-panel-goalstream" role="tabpanel" aria-labelledby="gtv-tab-goalstream" data-settings-panel="goalstream"' . ($activeTab !== 'goalstream' ? ' hidden' : '') . '>'
         . '<h2>GoalStream</h2><p class="gtv-help">Conecta la instalación de GoalStream para mostrar eventos deportivos. Solo se requiere su URL.</p>'
         . '<label>URL de tu instalación<input name="gs_url" value="' . $e($plugin->option('gs_url', '')) . '" placeholder="https://tu-otra-web.com/goalstream" style="' . $in . '"></label>'
         . ($gsMsg !== '' ? '<p style="margin:-6px 0 14px;font-size:13px;color:' . ($gsOk ? 'var(--accent-2)' : '#ff6b6b') . '">' . $e($gsMsg) . '</p>' : '')
         . '</section>'
         . '<div class="gtv-settings-actions"><button class="btn btn--primary" type="submit">Guardar ajustes</button></div>'
         . '</form><footer class="gtv-settings-footer"><span class="gtv-settings-footer__mark"><img src="' . $e($siteRoot . '/api/plugins-front.php?p=glitch-droid-interface&f=assets/icon-mobile.svg') . '" alt="Logo de Glitch Droid Interface"></span><span class="gtv-settings-footer__brand"><strong>Glitch Droid Interface</strong><small>Versión 1.0.0 · Interfaz móvil</small></span><span class="gtv-settings-footer__credit">Desarrollado por <a href="https://t.me/thesthipoficial" target="_blank" rel="noopener noreferrer">@Thesthipoficial</a></span></footer></div>';

    echo '<script>(function(){
"use strict";
var form=document.getElementById("gtvSettingsForm"),state=document.getElementById("gtvSettingsTabState");
if(!form||!state)return;
var tabs=form.querySelectorAll("[data-settings-tab]"),panels=form.querySelectorAll("[data-settings-panel]");
function activate(name){state.value=name;tabs.forEach(function(tab){var active=tab.getAttribute("data-settings-tab")===name;tab.setAttribute("aria-selected",active?"true":"false");tab.tabIndex=active?0:-1});panels.forEach(function(panel){panel.hidden=panel.getAttribute("data-settings-panel")!==name})}
tabs.forEach(function(tab,index){tab.addEventListener("click",function(){activate(tab.getAttribute("data-settings-tab"))});tab.addEventListener("keydown",function(event){if(event.key!=="ArrowLeft"&&event.key!=="ArrowRight")return;event.preventDefault();var next=(index+(event.key==="ArrowRight"?1:tabs.length-1))%tabs.length;tabs[next].focus();activate(tabs[next].getAttribute("data-settings-tab"))})});
activate(state.value||"general");
var preview=document.getElementById("gtvMaintenancePreview"),mark=document.getElementById("gtvMaintenancePreviewMark"),title=document.getElementById("gtvMaintenancePreviewTitle"),message=document.getElementById("gtvMaintenancePreviewMessage"),brand=document.getElementById("gtvMaintenancePreviewBrand");
if(!preview||!mark)return;
var iconValue=document.getElementById("gtvMaintenanceIconValue"),iconCustom=document.getElementById("gtvMaintenanceIconCustom"),imageUrl=document.getElementById("gtvMaintenanceImageUrl"),imageFile=document.getElementById("gtvMaintenanceImageFile"),objectUrl="";
function selectedIconButton(){return form.querySelector("[data-maintenance-icon].is-selected")}
function drawIcon(){var selected=selectedIconButton();mark.innerHTML="";if(selected){mark.innerHTML=selected.innerHTML;return}mark.textContent=(iconCustom&&iconCustom.value)||"!"}
function drawImage(){if(objectUrl){URL.revokeObjectURL(objectUrl);objectUrl=""}var file=imageFile&&imageFile.files&&imageFile.files[0],src=file?URL.createObjectURL(file):(imageUrl?imageUrl.value.trim():"");if(!src){drawIcon();return}if(file)objectUrl=src;var img=document.createElement("img");img.alt="";img.onload=function(){mark.replaceChildren(img)};img.onerror=function(){if(objectUrl){URL.revokeObjectURL(objectUrl);objectUrl=""}drawIcon()};img.src=src}
var logoUrl=document.getElementById("gtvLogoUrl"),logoFile=document.getElementById("gtvLogoFile"),logoPreview=document.getElementById("gtvLogoPreview"),logoRemove=document.getElementById("gtvRemoveLogo"),maintRemove=document.getElementById("gtvRemoveMaintenanceImage"),logoStatus=document.getElementById("gtvLogoStatus"),maintStatus=document.getElementById("gtvMaintenanceImageStatus"),maintPreview=document.getElementById("gtvMaintenanceImagePreview");
function renderUploadPreview(el,src,emptyText){if(!el)return;el.replaceChildren();if(!src){el.textContent=emptyText;return}var img=document.createElement("img");img.alt="Vista previa";img.src=src;img.onerror=function(){el.textContent="No se pudo cargar"};el.appendChild(img)}
function previewFile(input,preview,urlInput,removeInput,status,objectKey){
  var file=input&&input.files&&input.files[0],url=window[objectKey];
  if(url){URL.revokeObjectURL(url);window[objectKey]=""}
  if(file){
    if(file.size>8*1024*1024||!/^image\\//i.test(file.type)){input.value="";if(status){status.textContent="Selecciona una imagen válida de máximo 8 MB.";status.classList.add("is-error")}return}
    url=URL.createObjectURL(file);window[objectKey]=url;if(removeInput)removeInput.value="";if(status){status.textContent=file.name;status.classList.remove("is-error")}
  }else{url=urlInput&&urlInput.value.trim();if(!url&&removeInput&&removeInput.value!=="1")url=preview&&preview.getAttribute("data-current-src")||"";if(status){status.textContent="";status.classList.remove("is-error")}}
  renderUploadPreview(preview,url,"Sin imagen");
  return true;
}
function setupDrop(box,input,preview,urlInput,removeInput,status,objectKey){
  if(!box||!input)return;
  ["dragenter","dragover"].forEach(function(type){box.addEventListener(type,function(event){event.preventDefault();box.classList.add("is-dragging")})});
  ["dragleave","drop"].forEach(function(type){box.addEventListener(type,function(event){event.preventDefault();box.classList.remove("is-dragging")})});
  box.addEventListener("drop",function(event){var files=event.dataTransfer&&event.dataTransfer.files;if(!files||!files.length)return;try{var transfer=new DataTransfer();transfer.items.add(files[0]);input.files=transfer.files;input.dispatchEvent(new Event("change",{bubbles:true}))}catch(error){if(status){status.textContent="No se pudo adjuntar el archivo; selecciónalo con el botón.";status.classList.add("is-error")}}});
  input.addEventListener("change",function(){if(previewFile(input,preview,urlInput,removeInput,status,objectKey)===true&&input.files&&input.files[0]){if(urlInput)urlInput.value=""}});
  if(urlInput)urlInput.addEventListener("input",function(){if(input)input.value="";if(removeInput)removeInput.value="";previewFile(input,preview,urlInput,removeInput,status,objectKey)});
}
function setupRemove(button,input,urlInput,removeInput,preview,status,emptyText,afterRemove){
  if(!button)return;
  button.addEventListener("click",function(){if(input)input.value="";if(urlInput)urlInput.value="";if(removeInput)removeInput.value="1";renderUploadPreview(preview,"",emptyText);if(status){status.textContent="Se quitará al guardar.";status.classList.remove("is-error")}if(afterRemove)afterRemove()});
}
setupDrop(document.querySelector("[data-upload-box]"),logoFile,logoPreview,logoUrl,logoRemove,logoStatus,"gtvLogoObjectUrl");
setupDrop(document.getElementById("gtvMaintenanceUploadBox"),imageFile,maintPreview,imageUrl,maintRemove,maintStatus,"gtvMaintenanceObjectUrl");
setupRemove(document.getElementById("gtvRemoveLogoBtn"),logoFile,logoUrl,logoRemove,logoPreview,logoStatus,"Sin logo");
setupRemove(document.getElementById("gtvRemoveMaintenanceImageBtn"),imageFile,imageUrl,maintRemove,maintPreview,maintStatus,"Sin imagen",drawIcon);
function updatePreview(){if(title)title.textContent=(document.querySelector("[name=maintenance_title]")||{}).value||"Modo mantenimiento";if(message)message.textContent=(document.querySelector("[name=maintenance_message]")||{}).value||"Estamos realizando tareas de mantenimiento. Vuelve pronto.";if(brand)brand.textContent=(document.querySelector("[name=name]")||{}).value||"Glitch Droid";[ ["maintenance_bg","--preview-bg"],["maintenance_text","--preview-text"],["maintenance_accent","--preview-accent"],["theme_surface_alt","--preview-surface"] ].forEach(function(pair){var input=document.querySelector("[name="+pair[0]+"]");if(input)preview.style.setProperty(pair[1],input.value)});drawImage()}
form.querySelectorAll("[name=maintenance_title],[name=maintenance_message],[name=name],[name=maintenance_bg],[name=maintenance_text],[name=maintenance_accent],[name=theme_surface_alt]").forEach(function(input){input.addEventListener("input",updatePreview);input.addEventListener("change",updatePreview)});
form.querySelectorAll("[data-maintenance-icon]").forEach(function(button){button.addEventListener("click",function(){form.querySelectorAll("[data-maintenance-icon]").forEach(function(option){var active=option===button;option.classList.toggle("is-selected",active);option.setAttribute("aria-pressed",active?"true":"false")});if(iconValue)iconValue.value=button.getAttribute("data-maintenance-icon");if(iconCustom)iconCustom.value="";drawIcon()})});
if(iconCustom)iconCustom.addEventListener("input",function(){form.querySelectorAll("[data-maintenance-icon]").forEach(function(button){button.classList.remove("is-selected");button.setAttribute("aria-pressed","false")});if(iconValue)iconValue.value=iconCustom.value;drawIcon()});
if(imageUrl)imageUrl.addEventListener("input",drawImage);if(imageFile)imageFile.addEventListener("change",drawImage);
updatePreview();
})();</script>';
});
